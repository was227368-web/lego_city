package com.example.models

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.MonarchCyan
import com.example.ui.theme.MonarchGold
import com.example.ui.theme.MonarchPurple
import com.example.ui.theme.MonarchRed

enum class HunterRank(
    val titleEn: String,
    val titleAr: String,
    val minLevel: Int,
    val color: Color
) {
    E_RANK("E-Rank", "رتبة E", 1, Color(0xFF9E9E9E)),
    D_RANK("D-Rank", "رتبة D", 5, Color(0xFF26C6DA)),
    C_RANK("C-Rank", "رتبة C", 10, Color(0xFF42A5F5)),
    B_RANK("B-Rank", "رتبة B", 20, Color(0xFFAB47BC)),
    A_RANK("A-Rank", "رتبة A", 35, Color(0xFFFF5252)),
    S_RANK("S-Rank", "رتبة S", 50, Color(0xFFFFD700)),
    NATIONAL_LEVEL("National Level", "المستوى القومي", 75, Color(0xFFFF1744)),
    SHADOW_MONARCH("Shadow Monarch", "ملك الظلال", 100, Color(0xFF00E5FF));

    companion object {
        fun fromLevel(level: Int): HunterRank {
            return entries.reversed().firstOrNull { level >= it.minLevel } ?: E_RANK
        }
    }
}

data class HunterProfile(
    val fullName: String = "Sung Jin-Woo",
    val email: String = "hunter@monarch.system",
    val age: Int = 24,
    val avatarId: String = "img_jinwoo_mentor",
    val level: Int = 1,
    val currentXp: Int = 0,
    val streakDays: Int = 3,
    val totalQuestsCompleted: Int = 0,
    val selectedSectors: List<String> = listOf("STUDY", "BUSINESS", "FITNESS"),
    val language: String = "en",
    val soundEnabled: Boolean = true,
    val isLoggedIn: Boolean = false
) {
    val rank: HunterRank get() = HunterRank.fromLevel(level)

    // Formula requested: 100 + (Level - 1) * 25
    val maxXp: Int get() = 100 + (level - 1) * 25

    val xpProgress: Float get() = if (maxXp > 0) (currentXp.toFloat() / maxXp.toFloat()).coerceIn(0f, 1f) else 0f
}
