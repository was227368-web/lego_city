package com.example.models

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.MonarchCyan
import com.example.ui.theme.MonarchGold
import com.example.ui.theme.MonarchGreen
import com.example.ui.theme.MonarchPurple
import com.example.ui.theme.MonarchPurpleLight

enum class QuestType(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val badgeColor: Color
) {
    DAILY("DAILY", "Daily Quest", "مهمة يومية", MonarchCyan),
    MAIN("MAIN", "Main Quest", "مهمة رئيسية", MonarchGold),
    SIDE("SIDE", "Side Quest", "مهمة فرعية", MonarchPurpleLight);

    companion object {
        fun fromId(id: String): QuestType {
            return entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: DAILY
        }
    }
}

enum class SectorType(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val subcategoriesEn: List<String>,
    val subcategoriesAr: List<String>,
    val color: Color
) {
    STUDY(
        id = "STUDY",
        nameEn = "Study & Skills",
        nameAr = "الدراسة والمهارات",
        subcategoriesEn = listOf("Academic", "Self Development", "Skill Mastery"),
        subcategoriesAr = listOf("الأكاديمية", "التطوير الذاتي", "إتقان المهارات"),
        color = MonarchCyan
    ),
    BUSINESS(
        id = "BUSINESS",
        nameEn = "Business & Projects",
        nameAr = "الأعمال والمشاريع",
        subcategoriesEn = listOf("Project Management", "Growth", "New Venture"),
        subcategoriesAr = listOf("إدارة المشاريع", "النمو والتوسع", "مشاريع ناشئة"),
        color = MonarchPurple
    ),
    FITNESS(
        id = "FITNESS",
        nameEn = "Fitness & Healthy Habits",
        nameAr = "اللياقة والعادات الصحية",
        subcategoriesEn = listOf("Physical Activity", "Sleep", "General Fitness"),
        subcategoriesAr = listOf("النشاط البدني", "النوم الصحي", "اللياقة العامة"),
        color = MonarchGreen
    );

    companion object {
        fun fromId(id: String): SectorType {
            return entries.firstOrNull { it.id == id } ?: STUDY
        }
    }
}

data class Quest(
    val id: String,
    val title: String,
    val titleAr: String,
    val description: String,
    val descriptionAr: String,
    val sector: SectorType,
    val rank: String = "E", // E, D, C, B, A, S
    val durationMinutes: Int = 25,
    val xpReward: Int = 50,
    val isCompleted: Boolean = false,
    val isClaimed: Boolean = false,
    val questType: QuestType = QuestType.DAILY,
    val isDaily: Boolean = questType == QuestType.DAILY,
    val dueTime: String = "20:00",
    val reminderEnabled: Boolean = false,
    val reminderTimestamp: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)

data class RoadmapPhase(
    val phaseNumber: Int,
    val nameEn: String,
    val nameAr: String,
    val objectiveEn: String,
    val objectiveAr: String,
    val suggestedQuests: List<Quest>
)
