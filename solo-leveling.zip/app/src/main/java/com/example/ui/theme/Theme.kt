package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val MonarchColorScheme = darkColorScheme(
  primary = MonarchCyan,
  onPrimary = MonarchBg,
  primaryContainer = MonarchFrameBgLight,
  onPrimaryContainer = MonarchCyan,
  secondary = MonarchPurple,
  onSecondary = MonarchTextPrimary,
  secondaryContainer = MonarchFrameBgLight,
  onSecondaryContainer = MonarchPurpleLight,
  tertiary = MonarchGold,
  background = MonarchBg,
  onBackground = MonarchTextPrimary,
  surface = MonarchFrameBg,
  onSurface = MonarchTextPrimary,
  surfaceVariant = MonarchFrameBgLight,
  onSurfaceVariant = MonarchTextSecondary,
  outline = MonarchBorder,
  outlineVariant = MonarchBorderCyan
)

@Composable
fun SoloLevelingTheme(
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = MonarchColorScheme,
    typography = Typography,
    content = content
  )
}

