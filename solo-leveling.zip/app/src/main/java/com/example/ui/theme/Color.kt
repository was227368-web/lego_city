package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Monarch Cyberpunk aesthetic
val MonarchBg = Color(0xFF0A0C10)
val MonarchFrameBg = Color(0xFF141A26)
val MonarchFrameBgLight = Color(0xFF1B2333)
val MonarchCyan = Color(0xFF00E5FF)
val MonarchPurple = Color(0xFF8A2BE2)
val MonarchPurpleLight = Color(0xFFA855F7)
val MonarchCyanDark = Color(0xFF0097A7)
val MonarchGold = Color(0xFFFFD700)
val MonarchRed = Color(0xFFFF3366)
val MonarchGreen = Color(0xFF00E676)
val MonarchBorder = Color(0xFF223048)
val MonarchBorderCyan = Color(0xFF00E5FF)
val MonarchTextPrimary = Color(0xFFF0F6FC)
val MonarchTextSecondary = Color(0xFF8B949E)
val MonarchTextMuted = Color(0xFF586069)

