package com.example.util

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SoundEffectHelper(private val context: Context) {

    private var toneGen: ToneGenerator? = null
    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vm?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    init {
        try {
            toneGen = ToneGenerator(AudioManager.STREAM_MUSIC, 90)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun playAriseSound(soundEnabled: Boolean) {
        vibrate(longArrayOf(0, 100, 80, 250, 100, 400))
        if (!soundEnabled) return

        CoroutineScope(Dispatchers.IO).launch {
            try {
                toneGen?.startTone(ToneGenerator.TONE_PROP_BEEP2, 200)
                delay(220)
                toneGen?.startTone(ToneGenerator.TONE_CDMA_HIGH_L, 350)
                delay(380)
                toneGen?.startTone(ToneGenerator.TONE_DTMF_D, 500)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun playLevelUpSound(soundEnabled: Boolean) {
        vibrate(longArrayOf(0, 80, 50, 80, 50, 200))
        if (!soundEnabled) return

        CoroutineScope(Dispatchers.IO).launch {
            try {
                toneGen?.startTone(ToneGenerator.TONE_DTMF_1, 120)
                delay(130)
                toneGen?.startTone(ToneGenerator.TONE_DTMF_5, 140)
                delay(150)
                toneGen?.startTone(ToneGenerator.TONE_DTMF_9, 160)
                delay(170)
                toneGen?.startTone(ToneGenerator.TONE_PROP_ACK, 400)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun playTimerCompleteSound(soundEnabled: Boolean) {
        vibrate(longArrayOf(0, 200, 100, 200, 100, 400))
        if (!soundEnabled) return

        CoroutineScope(Dispatchers.IO).launch {
            try {
                repeat(3) {
                    toneGen?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 200)
                    delay(250)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun playQuestClaimSound(soundEnabled: Boolean) {
        vibrate(longArrayOf(0, 80, 50, 140))
        if (!soundEnabled) return

        CoroutineScope(Dispatchers.IO).launch {
            try {
                toneGen?.startTone(ToneGenerator.TONE_PROP_ACK, 250)
                delay(200)
                toneGen?.startTone(ToneGenerator.TONE_CDMA_HIGH_L, 350)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun vibrate(pattern: LongArray) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, -1)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
