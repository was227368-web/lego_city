package com.example.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class QuestReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        if (intent == null) return

        val questId = intent.getStringExtra("EXTRA_QUEST_ID") ?: return
        val questTitle = intent.getStringExtra("EXTRA_QUEST_TITLE") ?: "Hunter Quest"
        val questType = intent.getStringExtra("EXTRA_QUEST_TYPE") ?: "DAILY"
        val xpReward = intent.getIntExtra("EXTRA_XP_REWARD", 50)
        val isArabic = intent.getBooleanExtra("EXTRA_IS_ARABIC", false)

        val helper = NotificationHelper(context)
        helper.sendQuestReminderNotification(
            questTitle = questTitle,
            questType = questType,
            xpReward = xpReward,
            isArabic = isArabic
        )
    }
}
