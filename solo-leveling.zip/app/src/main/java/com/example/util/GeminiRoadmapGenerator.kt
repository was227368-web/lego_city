package com.example.util

import com.example.BuildConfig
import com.example.models.Quest
import com.example.models.QuestType
import com.example.models.RoadmapPhase
import com.example.models.SectorType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiRoadmapGenerator {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun generateRoadmap(
        projectName: String,
        projectDescription: String,
        isArabic: Boolean
    ): List<RoadmapPhase> = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Throwable) {
            ""
        }

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val generated = callGeminiApi(projectName, projectDescription, apiKey, isArabic)
                if (generated.isNotEmpty()) {
                    return@withContext generated
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // Return rich, tailored procedural 5-phase roadmap
        return@withContext generateProceduralRoadmap(projectName, projectDescription)
    }

    private fun callGeminiApi(
        projectName: String,
        projectDescription: String,
        apiKey: String,
        isArabic: Boolean
    ): List<RoadmapPhase> {
        val prompt = """
            You are Sung Jin-Woo's Shadow Monarch AI Business System.
            Create a structured 5-Phase business roadmap for:
            Project Name: $projectName
            Description: $projectDescription
            
            Strictly return a valid JSON array of 5 phases with this schema:
            [
              {
                "phaseNumber": 1,
                "nameEn": "Phase 1: Research & Discovery",
                "nameAr": "المرحلة 1: البحث والاستكشاف",
                "objectiveEn": "Validate market demand and competitor gaps",
                "objectiveAr": "التحقق من طلب السوق وتحليل ثغرات المنافسين",
                "quests": [
                  {
                    "title": "Analyze 5 Core Competitors",
                    "titleAr": "تحليل 5 منافسين رئيسيين",
                    "description": "Examine pricing, weaknesses, and features",
                    "descriptionAr": "فحص التسعير ونقاط الضعف والمميزات",
                    "durationMinutes": 45,
                    "xpReward": 80,
                    "rank": "E"
                  }
                ]
              },
              ...for 5 phases: Research, MVP, Tools, Launch, Growth.
            ]
            Return only the JSON array.
        """.trimIndent()

        val jsonBody = JSONObject().apply {
            val contentsArr = JSONArray()
            val contentObj = JSONObject()
            val partsArr = JSONArray()
            val partObj = JSONObject().apply { put("text", prompt) }
            partsArr.put(partObj)
            contentObj.put("parts", partsArr)
            contentsArr.put(contentObj)
            put("contents", contentsArr)
        }

        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()
        val resStr = response.body?.string() ?: return emptyList()

        val resJson = JSONObject(resStr)
        val candidates = resJson.optJSONArray("candidates") ?: return emptyList()
        val firstCandidate = candidates.optJSONObject(0) ?: return emptyList()
        val content = firstCandidate.optJSONObject("content") ?: return emptyList()
        val parts = content.optJSONArray("parts") ?: return emptyList()
        val text = parts.optJSONObject(0)?.optString("text") ?: return emptyList()

        val cleanJson = text.substringAfter("[").substringBeforeLast("]")
        val phasesJson = JSONArray("[$cleanJson]")
        val result = mutableListOf<RoadmapPhase>()

        for (i in 0 until phasesJson.length()) {
            val pObj = phasesJson.getJSONObject(i)
            val qList = mutableListOf<Quest>()
            val questsArr = pObj.optJSONArray("quests")
            if (questsArr != null) {
                for (j in 0 until questsArr.length()) {
                    val q = questsArr.getJSONObject(j)
                    qList.add(
                        Quest(
                            id = "ai_${System.currentTimeMillis()}_${i}_${j}",
                            title = q.optString("title", "Roadmap Quest"),
                            titleAr = q.optString("titleAr", "مهمة خارطة الطريق"),
                            description = q.optString("description", ""),
                            descriptionAr = q.optString("descriptionAr", ""),
                            sector = SectorType.BUSINESS,
                            rank = q.optString("rank", "D"),
                            durationMinutes = q.optInt("durationMinutes", 30),
                            xpReward = q.optInt("xpReward", 75),
                            isCompleted = false,
                            questType = QuestType.MAIN,
                            isDaily = false,
                            dueTime = "Phase ${i + 1}"
                        )
                    )
                }
            }
            result.add(
                RoadmapPhase(
                    phaseNumber = pObj.optInt("phaseNumber", i + 1),
                    nameEn = pObj.optString("nameEn", "Phase ${i + 1}"),
                    nameAr = pObj.optString("nameAr", "المرحلة ${i + 1}"),
                    objectiveEn = pObj.optString("objectiveEn", ""),
                    objectiveAr = pObj.optString("objectiveAr", ""),
                    suggestedQuests = qList
                )
            )
        }
        return result
    }

    fun generateProceduralRoadmap(
        projectName: String,
        projectDescription: String
    ): List<RoadmapPhase> {
        val name = if (projectName.isBlank()) "Shadow Venture" else projectName
        return listOf(
            RoadmapPhase(
                phaseNumber = 1,
                nameEn = "Phase 1: Research & Dungeon Recon",
                nameAr = "المرحلة 1: البحث واستطلاع البوابة",
                objectiveEn = "Scout market landscape, validate demand, and interview potential users for $name.",
                objectiveAr = "استكشاف مشهد السوق والتحقق من حجم الطلب وإجراء مقابلات مع الفئة المستهدفة لمشروع $name.",
                suggestedQuests = listOf(
                    Quest(
                        id = "p1_q1",
                        title = "Competitive Mana Recon for $name",
                        titleAr = "استطلاع المنافسين لمشروع $name",
                        description = "Analyze top 3 competing products and document feature gaps.",
                        descriptionAr = "تحليل أبرز 3 منافسين وتوثيق الثغرات في ميزاتهم.",
                        sector = SectorType.BUSINESS,
                        rank = "E",
                        durationMinutes = 35,
                        xpReward = 65
                    ),
                    Quest(
                        id = "p1_q2",
                        title = "User Problem Interviews (5 Targets)",
                        titleAr = "مقابلات تشخيص مشاكل العملاء (5 أهداف)",
                        description = "Conduct 5 interviews to identify core friction and pain points.",
                        descriptionAr = "إجراء 5 مقابلات لتحديد نقاط الألم والاحتياج الحقيقي.",
                        sector = SectorType.BUSINESS,
                        rank = "D",
                        durationMinutes = 45,
                        xpReward = 85
                    )
                )
            ),
            RoadmapPhase(
                phaseNumber = 2,
                nameEn = "Phase 2: Core MVP Architecture",
                nameAr = "المرحلة 2: هندسة وتطوير النموذج الأولي",
                objectiveEn = "Craft the minimum viable prototype focusing strictly on the primary value trigger.",
                objectiveAr = "بناء النموذج الأولي مع التركيز الحصري على تقديم القيمة الجوهرية للعميل.",
                suggestedQuests = listOf(
                    Quest(
                        id = "p2_q1",
                        title = "Wireframe & Value Proposition Flow",
                        titleAr = "رسم مخطط التدفق وعرض القيمة",
                        description = "Design intuitive user journey from landing to core activation.",
                        descriptionAr = "تصميم رحلة المستخدم بسلاسة من البداية حتى التفاعل الرئيسي.",
                        sector = SectorType.BUSINESS,
                        rank = "D",
                        durationMinutes = 40,
                        xpReward = 90
                    ),
                    Quest(
                        id = "p2_q2",
                        title = "Build & Deploy Core MVP Feature",
                        titleAr = "تطوير وإطلاق الميزة الأساسية للـ MVP",
                        description = "Implement the single most critical capability without distractions.",
                        descriptionAr = "برمجة أو تجهيز الميزة الفاصلة دون الانشغال بالإضافات الجانبية.",
                        sector = SectorType.BUSINESS,
                        rank = "C",
                        durationMinutes = 60,
                        xpReward = 120
                    )
                )
            ),
            RoadmapPhase(
                phaseNumber = 3,
                nameEn = "Phase 3: Tools & Shadow Automation",
                nameAr = "المرحلة 3: الأدوات وأتمتة الظلال",
                objectiveEn = "Set up analytics, payment/funnel infrastructure, and automated customer onboarding.",
                objectiveAr = "إعداد أدوات التحليل وبوابات الدفع وأتمتة تهيئة العملاء الجدد.",
                suggestedQuests = listOf(
                    Quest(
                        id = "p3_q1",
                        title = "Setup Metrics & Conversion Funnel",
                        titleAr = "ضبط مؤشرات الأداء وقمع التحويل",
                        description = "Configure tracking for signups, retention, and drop-off points.",
                        descriptionAr = "تفعيل مقاييس التسجيل ومعدل الاستبقاء ونقاط التراجع.",
                        sector = SectorType.BUSINESS,
                        rank = "C",
                        durationMinutes = 30,
                        xpReward = 80
                    ),
                    Quest(
                        id = "p3_q2",
                        title = "Automated Communication Sequence",
                        titleAr = "سلسلة الرسائل الآلية للترحيب",
                        description = "Draft automated welcome sequence to engage new hunters.",
                        descriptionAr = "إعداد رسائل ترحيبية وتوجيهية تلقائية للمستخدمين الجدد.",
                        sector = SectorType.BUSINESS,
                        rank = "D",
                        durationMinutes = 35,
                        xpReward = 75
                    )
                )
            ),
            RoadmapPhase(
                phaseNumber = 4,
                nameEn = "Phase 4: Launch & Awakening Gate",
                nameAr = "المرحلة 4: الإطلاق وفتح بوابة الصيادين",
                objectiveEn = "Public unveiling of $name to early adopters and community channels.",
                objectiveAr = "الإطلاق العام لمشروع $name واستقطاب أوائل المستخدمين النشطين.",
                suggestedQuests = listOf(
                    Quest(
                        id = "p4_q1",
                        title = "Public Announcement & Community Raid",
                        titleAr = "الإعلان العام وحملة النشر المجتمعي",
                        description = "Broadcast launch across targeted tech forums and social groups.",
                        descriptionAr = "نشر الإطلاق في المنتديات المتخصصة وقنوات التواصل المستهدفة.",
                        sector = SectorType.BUSINESS,
                        rank = "B",
                        durationMinutes = 50,
                        xpReward = 140
                    ),
                    Quest(
                        id = "p4_q2",
                        title = "Gather First 20 Customer Reviews",
                        titleAr = "جمع آراء أول 20 مستخدماً فعلياً",
                        description = "Conduct feedback loops to refine flaws and highlight testimonials.",
                        descriptionAr = "إجراء استبيانات فورية لتحسين المنتج وجمع شهادات النجاح.",
                        sector = SectorType.BUSINESS,
                        rank = "B",
                        durationMinutes = 40,
                        xpReward = 110
                    )
                )
            ),
            RoadmapPhase(
                phaseNumber = 5,
                nameEn = "Phase 5: Growth & Monarch Domination",
                nameAr = "المرحلة 5: التوسع والسيادة الملكية",
                objectiveEn = "Scale marketing channels, optimize retention, and expand feature offerings.",
                objectiveAr = "توسيع قنوات التسويق وتحسين معدل ولاء العملاء وتطوير الخدمات.",
                suggestedQuests = listOf(
                    Quest(
                        id = "p5_q1",
                        title = "Referral & Virality Engine",
                        titleAr = "محرك الإحالة والانتشار الفيروسي",
                        description = "Incentivize existing users to recruit fellow hunters.",
                        descriptionAr = "تحفيز المستخدمين الحاليين على دعوة أصدقائهم عبر مكافآت مجزية.",
                        sector = SectorType.BUSINESS,
                        rank = "A",
                        durationMinutes = 45,
                        xpReward = 160
                    ),
                    Quest(
                        id = "p5_q2",
                        title = "Monthly Performance Calibration",
                        titleAr = "مراجعة الأداء الشهري واستراتيجية التوسع",
                        description = "Review unit economics, churn rate, and scale team capacity.",
                        descriptionAr = "مراجعة اقتصاديات الوحدة وتوسيع قدرات الفريق التشغيلية.",
                        sector = SectorType.BUSINESS,
                        rank = "S",
                        durationMinutes = 55,
                        xpReward = 200
                    )
                )
            )
        )
    }
}
