package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.example.data.UserDataRepository
import com.example.models.HunterProfile
import com.example.models.Quest
import com.example.screens.AiRoadmapScreen
import com.example.screens.AriseScreen
import com.example.screens.AuthScreen
import com.example.screens.CategorySelectionScreen
import com.example.screens.MonarchDashboardScreen
import com.example.screens.ProfileDrawerContent
import com.example.screens.SplashScreen
import com.example.ui.theme.SoloLevelingTheme
import com.example.util.NotificationHelper
import com.example.util.SoundEffectHelper
import kotlinx.coroutines.launch

enum class Screen {
    SPLASH,
    AUTH,
    CATEGORY_SELECTION,
    AI_ROADMAP,
    ARISE_TARGET,
    DASHBOARD
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            SoloLevelingApp()
        }
    }
}

@Composable
fun SoloLevelingApp() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val repository = remember { UserDataRepository(context) }
    val soundHelper = remember { SoundEffectHelper(context) }
    val notificationHelper = remember { NotificationHelper(context) }

    var currentScreen by remember { mutableStateOf(Screen.SPLASH) }
    var previousScreen by remember { mutableStateOf<Screen?>(null) }

    var profile by remember { mutableStateOf(HunterProfile()) }
    var quests by remember { mutableStateOf<List<Quest>>(emptyList()) }
    var isDataLoaded by remember { mutableStateOf(false) }

    // Load persisted data on launch
    LaunchedEffect(Unit) {
        val (loadedProfile, loadedQuests) = repository.loadData()
        profile = loadedProfile
        quests = loadedQuests
        isDataLoaded = true
    }

    // Save changes to user_data.json
    fun persistData(newProfile: HunterProfile = profile, newQuests: List<Quest> = quests) {
        profile = newProfile
        quests = newQuests
        coroutineScope.launch {
            repository.saveData(newProfile, newQuests)
        }
    }

    // Award XP and calculate dynamic leveling: 100 + (Level - 1) * 25
    fun awardXp(xpReward: Int) {
        var currentXp = profile.currentXp + xpReward
        var currentLevel = profile.level
        var requiredXp = 100 + (currentLevel - 1) * 25

        var leveledUp = false
        while (currentXp >= requiredXp) {
            currentXp -= requiredXp
            currentLevel++
            requiredXp = 100 + (currentLevel - 1) * 25
            leveledUp = true
        }

        val updatedProfile = profile.copy(
            level = currentLevel,
            currentXp = currentXp,
            totalQuestsCompleted = profile.totalQuestsCompleted + 1
        )
        persistData(newProfile = updatedProfile)

        if (leveledUp) {
            soundHelper.playLevelUpSound(profile.soundEnabled)
        }
    }

    val isArabic = profile.language == "ar"
    val layoutDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    BackHandler(enabled = currentScreen != Screen.DASHBOARD && currentScreen != Screen.SPLASH) {
        when (currentScreen) {
            Screen.AI_ROADMAP -> currentScreen = Screen.CATEGORY_SELECTION
            Screen.ARISE_TARGET -> currentScreen = Screen.CATEGORY_SELECTION
            Screen.CATEGORY_SELECTION -> currentScreen = Screen.DASHBOARD
            Screen.AUTH -> currentScreen = Screen.SPLASH
            else -> {}
        }
    }

    SoloLevelingTheme {
        CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
            ModalNavigationDrawer(
                drawerState = drawerState,
                gesturesEnabled = currentScreen == Screen.DASHBOARD,
                drawerContent = {
                    ProfileDrawerContent(
                        profile = profile,
                        language = profile.language,
                        onLanguageToggle = { newLang ->
                            persistData(newProfile = profile.copy(language = newLang))
                        },
                        onToggleSound = { enabled ->
                            persistData(newProfile = profile.copy(soundEnabled = enabled))
                        },
                        onSelectAvatar = { avatarId ->
                            persistData(newProfile = profile.copy(avatarId = avatarId))
                        },
                        onLogout = {
                            coroutineScope.launch {
                                drawerState.close()
                                persistData(newProfile = profile.copy(isLoggedIn = false))
                                currentScreen = Screen.AUTH
                            }
                        },
                        onClose = {
                            coroutineScope.launch { drawerState.close() }
                        }
                    )
                }
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    when (currentScreen) {
                        Screen.SPLASH -> {
                            SplashScreen(
                                language = profile.language,
                                onLanguageChange = { newLang ->
                                    persistData(newProfile = profile.copy(language = newLang))
                                },
                                onInitializeComplete = {
                                    currentScreen = if (profile.isLoggedIn) Screen.DASHBOARD else Screen.AUTH
                                },
                                onPlaySound = {
                                    soundHelper.playAriseSound(profile.soundEnabled)
                                }
                            )
                        }

                        Screen.AUTH -> {
                            AuthScreen(
                                currentProfile = profile,
                                language = profile.language,
                                onLanguageChange = { newLang ->
                                    persistData(newProfile = profile.copy(language = newLang))
                                },
                                onAuthSuccess = { updatedProfile ->
                                    persistData(newProfile = updatedProfile.copy(isLoggedIn = true))
                                    currentScreen = Screen.CATEGORY_SELECTION
                                }
                            )
                        }

                        Screen.CATEGORY_SELECTION -> {
                            CategorySelectionScreen(
                                initialSectors = profile.selectedSectors,
                                language = profile.language,
                                onLanguageChange = { newLang ->
                                    persistData(newProfile = profile.copy(language = newLang))
                                },
                                onNavigateToAiRoadmap = {
                                    previousScreen = Screen.CATEGORY_SELECTION
                                    currentScreen = Screen.AI_ROADMAP
                                },
                                onProceedToTargetActivation = { selected ->
                                    persistData(newProfile = profile.copy(selectedSectors = selected))
                                    currentScreen = Screen.ARISE_TARGET
                                }
                            )
                        }

                        Screen.AI_ROADMAP -> {
                            AiRoadmapScreen(
                                language = profile.language,
                                onLanguageChange = { newLang ->
                                    persistData(newProfile = profile.copy(language = newLang))
                                },
                                onBack = {
                                    currentScreen = previousScreen ?: Screen.DASHBOARD
                                },
                                onImportQuestsToMatrix = { importedQuests ->
                                    val merged = quests + importedQuests
                                    persistData(newQuests = merged)
                                }
                            )
                        }

                        Screen.ARISE_TARGET -> {
                            AriseScreen(
                                profile = profile,
                                language = profile.language,
                                onLanguageChange = { newLang ->
                                    persistData(newProfile = profile.copy(language = newLang))
                                },
                                onEnterDashboard = {
                                    currentScreen = Screen.DASHBOARD
                                },
                                onPlayAriseSound = {
                                    soundHelper.playAriseSound(profile.soundEnabled)
                                }
                            )
                        }

                        Screen.DASHBOARD -> {
                            MonarchDashboardScreen(
                                profile = profile,
                                quests = quests,
                                language = profile.language,
                                onLanguageChange = { newLang ->
                                    persistData(newProfile = profile.copy(language = newLang))
                                },
                                onOpenDrawer = {
                                    coroutineScope.launch { drawerState.open() }
                                },
                                onNavigateToAiRoadmap = {
                                    previousScreen = Screen.DASHBOARD
                                    currentScreen = Screen.AI_ROADMAP
                                },
                                onAddQuest = { newQuest ->
                                    val updated = listOf(newQuest) + quests
                                    if (newQuest.reminderEnabled && newQuest.reminderTimestamp > System.currentTimeMillis()) {
                                        val qTitle = if (isArabic) newQuest.titleAr else newQuest.title
                                        notificationHelper.scheduleQuestReminder(
                                            questId = newQuest.id,
                                            questTitle = qTitle,
                                            questType = newQuest.questType.id,
                                            xpReward = newQuest.xpReward,
                                            triggerAtMillis = newQuest.reminderTimestamp,
                                            isArabic = isArabic
                                        )
                                    }
                                    persistData(newQuests = updated)
                                },
                                onCompleteQuest = { completedQuest ->
                                    val wasClaimed = completedQuest.isClaimed
                                    val updated = quests.map {
                                        if (it.id == completedQuest.id) it.copy(isCompleted = true, isClaimed = true) else it
                                    }
                                    if (!wasClaimed) {
                                        soundHelper.playQuestClaimSound(profile.soundEnabled)
                                        awardXp(completedQuest.xpReward)
                                    }
                                    persistData(newQuests = updated)
                                },
                                onToggleQuestCompletion = { targetQuest, isDone ->
                                    val wasClaimed = targetQuest.isClaimed
                                    val shouldClaim = isDone && !wasClaimed
                                    val updated = quests.map {
                                        if (it.id == targetQuest.id) {
                                            it.copy(
                                                isCompleted = isDone,
                                                isClaimed = if (shouldClaim) true else it.isClaimed
                                            )
                                        } else it
                                    }
                                    if (shouldClaim) {
                                        soundHelper.playQuestClaimSound(profile.soundEnabled)
                                        awardXp(targetQuest.xpReward)
                                    }
                                    persistData(newQuests = updated)
                                },
                                onToggleReminder = { quest, enabled, triggerMillis ->
                                    val updated = quests.map {
                                        if (it.id == quest.id) {
                                            it.copy(
                                                reminderEnabled = enabled,
                                                reminderTimestamp = if (enabled) triggerMillis else 0L
                                            )
                                        } else it
                                    }
                                    if (enabled && triggerMillis > System.currentTimeMillis()) {
                                        val qTitle = if (isArabic) quest.titleAr else quest.title
                                        notificationHelper.scheduleQuestReminder(
                                            questId = quest.id,
                                            questTitle = qTitle,
                                            questType = quest.questType.id,
                                            xpReward = quest.xpReward,
                                            triggerAtMillis = triggerMillis,
                                            isArabic = isArabic
                                        )
                                    } else {
                                        notificationHelper.cancelQuestReminder(quest.id)
                                    }
                                    persistData(newQuests = updated)
                                },
                                onTimerFinished = { timedQuest ->
                                    val wasClaimed = timedQuest.isClaimed
                                    val updated = quests.map {
                                        if (it.id == timedQuest.id) it.copy(isCompleted = true, isClaimed = true) else it
                                    }
                                    soundHelper.playTimerCompleteSound(profile.soundEnabled)
                                    val qTitle = if (isArabic) timedQuest.titleAr else timedQuest.title
                                    notificationHelper.sendQuestFinishedNotification(
                                        questTitle = qTitle,
                                        xpReward = timedQuest.xpReward,
                                        isArabic = isArabic
                                    )
                                    if (!wasClaimed) {
                                        awardXp(timedQuest.xpReward)
                                    }
                                    persistData(newQuests = updated)
                                },
                                onPlayLevelUpSound = {
                                    soundHelper.playLevelUpSound(profile.soundEnabled)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
