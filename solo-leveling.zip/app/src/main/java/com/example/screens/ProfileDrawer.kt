package com.example.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.components.CyberpunkCard
import com.example.components.HunterRankBadge
import com.example.components.StatBar
import com.example.models.HunterProfile
import com.example.ui.theme.MonarchBg
import com.example.ui.theme.MonarchBorder
import com.example.ui.theme.MonarchBorderCyan
import com.example.ui.theme.MonarchCyan
import com.example.ui.theme.MonarchFrameBg
import com.example.ui.theme.MonarchFrameBgLight
import com.example.ui.theme.MonarchGold
import com.example.ui.theme.MonarchPurple
import com.example.ui.theme.MonarchPurpleLight
import com.example.ui.theme.MonarchRed
import com.example.ui.theme.MonarchTextPrimary
import com.example.ui.theme.MonarchTextSecondary
import com.example.util.LanguageManager

@Composable
fun ProfileDrawerContent(
    profile: HunterProfile,
    language: String,
    onLanguageToggle: (String) -> Unit,
    onToggleSound: (Boolean) -> Unit,
    onSelectAvatar: (String) -> Unit,
    onLogout: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isArabic = language == "ar"

    val avatarDrawable = when (profile.avatarId) {
        "img_avatar_shadow" -> R.drawable.img_avatar_shadow
        "img_avatar_mage" -> R.drawable.img_avatar_mage
        else -> R.drawable.img_jinwoo_mentor
    }

    val avatars = listOf(
        "img_jinwoo_mentor" to R.drawable.img_jinwoo_mentor,
        "img_avatar_shadow" to R.drawable.img_avatar_shadow,
        "img_avatar_mage" to R.drawable.img_avatar_mage
    )

    Box(
        modifier = modifier
            .fillMaxHeight()
            .width(320.dp)
            .background(MonarchFrameBg)
            .border(1.dp, MonarchBorderCyan, RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp))
            .padding(20.dp)
    ) {
        Column(modifier = Modifier.fillMaxHeight()) {
            // Header with Close
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = LanguageManager.getText("drawer_title", isArabic),
                    color = MonarchCyan,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp,
                    fontFamily = FontFamily.Monospace
                )
                IconButton(onClick = onClose) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = MonarchTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Profile info
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .border(
                            2.dp,
                            Brush.sweepGradient(listOf(MonarchCyan, MonarchPurpleLight, MonarchCyan)),
                            CircleShape
                        )
                ) {
                    Image(
                        painter = painterResource(id = avatarDrawable),
                        contentDescription = profile.fullName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = profile.fullName,
                        color = MonarchTextPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = profile.email,
                        color = MonarchTextSecondary,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    HunterRankBadge(rank = profile.rank, isArabic = isArabic)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Avatar quick switcher
            Text(
                text = if (isArabic) "تغيير المظهر:" else "Change Avatar:",
                color = MonarchTextSecondary,
                fontSize = 11.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                avatars.forEach { (id, res) ->
                    val isSelected = profile.avatarId == id
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) MonarchCyan else MonarchBorder,
                                shape = CircleShape
                            )
                            .clickable { onSelectAvatar(id) }
                    ) {
                        Image(
                            painter = painterResource(id = res),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
            HorizontalDivider(color = MonarchBorder)
            Spacer(modifier = Modifier.height(16.dp))

            // RPG Stats
            StatBar(
                current = profile.currentXp,
                max = profile.maxXp,
                label = "${LanguageManager.getText("level", isArabic)} ${profile.level} ${LanguageManager.getText("xp", isArabic)}",
                barColor = MonarchCyan
            )

            Spacer(modifier = Modifier.height(12.dp))

            CyberpunkCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = MonarchFrameBgLight,
                borderColor = MonarchBorder
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "🔥 ${profile.streakDays}",
                            color = MonarchGold,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = LanguageManager.getText("streak", isArabic),
                            color = MonarchTextSecondary,
                            fontSize = 10.sp
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "⚔️ ${profile.totalQuestsCompleted}",
                            color = MonarchCyan,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = LanguageManager.getText("completed_quests", isArabic),
                            color = MonarchTextSecondary,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            HorizontalDivider(color = MonarchBorder)
            Spacer(modifier = Modifier.height(16.dp))

            // Settings: Language toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onLanguageToggle(if (isArabic) "en" else "ar") }
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Language, contentDescription = null, tint = MonarchCyan, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = LanguageManager.getText("language_label", isArabic),
                    color = MonarchTextPrimary,
                    fontSize = 14.sp,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = if (isArabic) "العربية" else "English",
                    color = MonarchCyan,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Settings: Sound FX toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null, tint = MonarchPurpleLight, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = LanguageManager.getText("sound_label", isArabic),
                    color = MonarchTextPrimary,
                    fontSize = 14.sp,
                    modifier = Modifier.weight(1f)
                )
                Switch(
                    checked = profile.soundEnabled,
                    onCheckedChange = onToggleSound,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = MonarchCyan,
                        checkedTrackColor = MonarchPurple,
                        uncheckedThumbColor = MonarchTextSecondary,
                        uncheckedTrackColor = MonarchFrameBgLight
                    )
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            // Sign out
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MonarchRed.copy(alpha = 0.12f))
                    .border(1.dp, MonarchRed.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    .clickable { onLogout() }
                    .padding(12.dp)
                    .testTag("drawer_logout_button"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, tint = MonarchRed, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = LanguageManager.getText("sign_out", isArabic),
                    color = MonarchRed,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
