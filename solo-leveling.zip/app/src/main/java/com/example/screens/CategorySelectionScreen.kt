package com.example.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.components.CyberpunkButton
import com.example.components.CyberpunkCard
import com.example.components.JinWooMentorCard
import com.example.components.LanguageToggleButton
import com.example.models.SectorType
import com.example.ui.theme.MonarchBg
import com.example.ui.theme.MonarchBorder
import com.example.ui.theme.MonarchBorderCyan
import com.example.ui.theme.MonarchCyan
import com.example.ui.theme.MonarchFrameBg
import com.example.ui.theme.MonarchFrameBgLight
import com.example.ui.theme.MonarchPurple
import com.example.ui.theme.MonarchPurpleLight
import com.example.ui.theme.MonarchTextPrimary
import com.example.ui.theme.MonarchTextSecondary
import com.example.util.LanguageManager

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CategorySelectionScreen(
    initialSectors: List<String>,
    language: String,
    onLanguageChange: (String) -> Unit,
    onNavigateToAiRoadmap: () -> Unit,
    onProceedToTargetActivation: (List<String>) -> Unit
) {
    val isArabic = language == "ar"
    var selectedSectors by remember { mutableStateOf(initialSectors.toSet()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MonarchBg)
            .padding(horizontal = 20.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Spacer(modifier = Modifier.height(24.dp))

        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .background(MonarchPurple.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                    .border(1.dp, MonarchPurple.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "SECTOR CALIBRATION",
                    color = MonarchCyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            LanguageToggleButton(
                currentLanguage = language,
                onLanguageToggle = onLanguageChange
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = LanguageManager.getText("sectors_title", isArabic),
            color = MonarchTextPrimary,
            fontSize = 22.sp,
            fontWeight = FontWeight.Black
        )

        Text(
            text = LanguageManager.getText("sectors_sub", isArabic),
            color = MonarchTextSecondary,
            fontSize = 13.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Sung Jin-Woo Mentor
        JinWooMentorCard(
            dialogueText = LanguageManager.getText("mentor_sectors", isArabic),
            isArabic = isArabic
        )

        Spacer(modifier = Modifier.height(20.dp))

        // 3 Sectors
        SectorType.entries.forEach { sector ->
            val isSelected = selectedSectors.contains(sector.id)
            val icon = when (sector) {
                SectorType.STUDY -> Icons.AutoMirrored.Filled.MenuBook
                SectorType.BUSINESS -> Icons.Default.RocketLaunch
                SectorType.FITNESS -> Icons.Default.FitnessCenter
            }
            val title = if (isArabic) sector.nameAr else sector.nameEn
            val subcategories = if (isArabic) sector.subcategoriesAr else sector.subcategoriesEn

            CyberpunkCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .clickable {
                        selectedSectors = if (isSelected) {
                            if (selectedSectors.size > 1) selectedSectors - sector.id else selectedSectors
                        } else {
                            selectedSectors + sector.id
                        }
                    },
                borderColor = if (isSelected) sector.color else MonarchBorder,
                borderWidth = if (isSelected) 2.dp else 1.dp,
                backgroundColor = if (isSelected) MonarchFrameBgLight else MonarchFrameBg
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(sector.color.copy(alpha = 0.2f))
                                .border(1.dp, sector.color, RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = title,
                                tint = sector.color,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = title,
                                color = MonarchTextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isSelected) (if (isArabic) "مفعّل في مصفوفة المهام" else "Active in Quest Matrix") else (if (isArabic) "انقر للتفعيل" else "Tap to activate"),
                                color = if (isSelected) sector.color else MonarchTextSecondary,
                                fontSize = 11.sp
                            )
                        }

                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Selected",
                                tint = sector.color,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Subcategories flow chips
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        subcategories.forEach { sub ->
                            Box(
                                modifier = Modifier
                                    .background(MonarchBg, RoundedCornerShape(16.dp))
                                    .border(1.dp, sector.color.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = sub,
                                    color = MonarchTextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // AI Business Assistant Shortcut Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(
                    Brush.horizontalGradient(
                        listOf(MonarchPurple.copy(alpha = 0.4f), MonarchCyan.copy(alpha = 0.3f))
                    )
                )
                .border(1.dp, MonarchPurpleLight, RoundedCornerShape(12.dp))
                .clickable { onNavigateToAiRoadmap() }
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = MonarchCyan,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = LanguageManager.getText("ai_business_title", isArabic),
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = LanguageManager.getText("ai_business_sub", isArabic),
                        color = MonarchTextSecondary,
                        fontSize = 11.sp
                    )
                }
                Text(
                    text = "➔",
                    color = MonarchCyan,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Confirm Button -> Proceeds to Target Activation ("ARISE")
        CyberpunkButton(
            text = LanguageManager.getText("proceed_to_arise", isArabic),
            onClick = {
                onProceedToTargetActivation(selectedSectors.toList())
            },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("proceed_arise_button"),
            isPrimary = true
        )

        Spacer(modifier = Modifier.height(30.dp))
    }
}
