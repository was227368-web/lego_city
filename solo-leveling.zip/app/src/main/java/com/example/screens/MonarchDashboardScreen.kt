package com.example.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import com.example.R
import com.example.components.CyberpunkButton
import com.example.components.CyberpunkCard
import com.example.components.HunterRankBadge
import com.example.components.JinWooMentorCard
import com.example.components.LanguageToggleButton
import com.example.components.StatBar
import com.example.models.HunterProfile
import com.example.models.HunterRank
import com.example.models.Quest
import com.example.models.QuestType
import com.example.models.SectorType
import com.example.ui.theme.MonarchBg
import com.example.ui.theme.MonarchBorder
import com.example.ui.theme.MonarchBorderCyan
import com.example.ui.theme.MonarchCyan
import com.example.ui.theme.MonarchFrameBg
import com.example.ui.theme.MonarchFrameBgLight
import com.example.ui.theme.MonarchGold
import com.example.ui.theme.MonarchGreen
import com.example.ui.theme.MonarchPurple
import com.example.ui.theme.MonarchPurpleLight
import com.example.ui.theme.MonarchRed
import com.example.ui.theme.MonarchTextMuted
import com.example.ui.theme.MonarchTextPrimary
import com.example.ui.theme.MonarchTextSecondary
import com.example.util.LanguageManager
import kotlinx.coroutines.delay

@Composable
fun MonarchDashboardScreen(
    profile: HunterProfile,
    quests: List<Quest>,
    language: String,
    onLanguageChange: (String) -> Unit,
    onOpenDrawer: () -> Unit,
    onNavigateToAiRoadmap: () -> Unit,
    onAddQuest: (Quest) -> Unit,
    onCompleteQuest: (Quest) -> Unit,
    onToggleQuestCompletion: (Quest, Boolean) -> Unit = { q, _ -> onCompleteQuest(q) },
    onToggleReminder: (Quest, Boolean, Long) -> Unit = { _, _, _ -> },
    onTimerFinished: (Quest) -> Unit,
    onPlayLevelUpSound: () -> Unit
) {
    val context = LocalContext.current
    val isArabic = language == "ar"

    var selectedTypeFilter by remember { mutableStateOf("ALL") }
    var selectedSectorFilter by remember { mutableStateOf("ALL") }
    var selectedStatusFilter by remember { mutableStateOf("ALL") }

    var showCreateQuestDialog by remember { mutableStateOf(false) }
    var reminderTargetQuest by remember { mutableStateOf<Quest?>(null) }
    var activeTimerQuest by remember { mutableStateOf<Quest?>(null) }
    var showLevelUpPopup by remember { mutableStateOf<Pair<Int, HunterRank>?>(null) }
    var toastMessage by remember { mutableStateOf<String?>(null) }

    // Auto-dismiss toast
    LaunchedEffect(toastMessage) {
        if (toastMessage != null) {
            delay(2500)
            toastMessage = null
        }
    }

    // Permission launcher for Android 13+
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    // Check level up from previous state
    var previousLevel by remember { mutableIntStateOf(profile.level) }
    LaunchedEffect(profile.level) {
        if (profile.level > previousLevel) {
            showLevelUpPopup = Pair(profile.level, profile.rank)
            onPlayLevelUpSound()
            previousLevel = profile.level
        }
    }

    // Filter quests
    val filteredQuests = remember(quests, selectedTypeFilter, selectedSectorFilter, selectedStatusFilter) {
        quests.filter { quest ->
            val matchesType = when (selectedTypeFilter) {
                "DAILY" -> quest.questType == QuestType.DAILY
                "MAIN" -> quest.questType == QuestType.MAIN
                "SIDE" -> quest.questType == QuestType.SIDE
                else -> true
            }
            val matchesSector = selectedSectorFilter == "ALL" || quest.sector.id == selectedSectorFilter
            val matchesStatus = when (selectedStatusFilter) {
                "ACTIVE" -> !quest.isCompleted
                "CLEARED" -> quest.isCompleted
                else -> true
            }
            matchesType && matchesSector && matchesStatus
        }
    }

    val avatarDrawable = when (profile.avatarId) {
        "img_avatar_shadow" -> R.drawable.img_avatar_shadow
        "img_avatar_mage" -> R.drawable.img_avatar_mage
        else -> R.drawable.img_jinwoo_mentor
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MonarchBg,
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    requestNotificationPermissionIfNeeded()
                    showCreateQuestDialog = true
                },
                containerColor = MonarchCyan,
                contentColor = MonarchBg,
                shape = CircleShape,
                modifier = Modifier.testTag("add_quest_fab")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add Quest",
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(16.dp))

                    // Top Navigation Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onOpenDrawer,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MonarchFrameBgLight)
                                .border(1.dp, MonarchBorder, RoundedCornerShape(8.dp))
                                .testTag("open_drawer_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "Open Drawer",
                                tint = MonarchCyan
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // AI Roadmap generator shortcut button
                            IconButton(
                                onClick = onNavigateToAiRoadmap,
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MonarchPurple.copy(alpha = 0.25f))
                                    .border(1.dp, MonarchPurpleLight, RoundedCornerShape(8.dp))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = "AI Business Roadmap",
                                    tint = MonarchCyan
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            LanguageToggleButton(
                                currentLanguage = language,
                                onLanguageToggle = onLanguageChange
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // HUNTER STATS HEADER (Dynamic level & XP progress bar)
                    CyberpunkCard(
                        modifier = Modifier.fillMaxWidth(),
                        borderColor = MonarchBorderCyan,
                        borderWidth = 1.5.dp
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Avatar
                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(CircleShape)
                                        .border(
                                            2.dp,
                                            Brush.sweepGradient(listOf(MonarchCyan, MonarchPurpleLight, MonarchCyan)),
                                            CircleShape
                                        )
                                        .clickable { onOpenDrawer() }
                                ) {
                                    Image(
                                        painter = painterResource(id = avatarDrawable),
                                        contentDescription = profile.fullName,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = profile.fullName,
                                            color = MonarchTextPrimary,
                                            fontSize = 17.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        HunterRankBadge(rank = profile.rank, isArabic = isArabic)
                                    }

                                    Spacer(modifier = Modifier.height(2.dp))

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "${LanguageManager.getText("level", isArabic)} ${profile.level}",
                                            color = MonarchCyan,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = "•", color = MonarchTextMuted)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "🔥 ${profile.streakDays} ${LanguageManager.getText("days", isArabic)}",
                                            color = MonarchGold,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = "•", color = MonarchTextMuted)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "⚔️ ${profile.totalQuestsCompleted}",
                                            color = MonarchPurpleLight,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // XP Progress Bar
                            StatBar(
                                current = profile.currentXp,
                                max = profile.maxXp,
                                label = "${LanguageManager.getText("xp", isArabic)}: ${profile.currentXp} / ${profile.maxXp}",
                                barColor = MonarchCyan
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Sung Jin-Woo Mentor Card
                    JinWooMentorCard(
                        dialogueText = LanguageManager.getText("mentor_dashboard", isArabic),
                        isArabic = isArabic
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // MATRIX HEADER & PROGRESS
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = LanguageManager.getText("dashboard_title", isArabic),
                            color = MonarchTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.sp
                        )

                        Text(
                            text = "${quests.count { it.isCompleted }} / ${quests.size} ${LanguageManager.getText("completed", isArabic)}",
                            color = MonarchCyan,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // QUEST TYPE TABS (Daily, Main, Side, All)
                    val questTypeTabs = listOf(
                        "ALL" to "${LanguageManager.getText("tab_all_quests", isArabic)} (${quests.size})",
                        "DAILY" to "${LanguageManager.getText("tab_daily", isArabic)} (${quests.count { it.questType == QuestType.DAILY }})",
                        "MAIN" to "${LanguageManager.getText("tab_main", isArabic)} (${quests.count { it.questType == QuestType.MAIN }})",
                        "SIDE" to "${LanguageManager.getText("tab_side", isArabic)} (${quests.count { it.questType == QuestType.SIDE }})"
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MonarchFrameBg)
                            .border(1.dp, MonarchBorder, RoundedCornerShape(10.dp))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        questTypeTabs.forEach { (key, label) ->
                            val isSelected = selectedTypeFilter == key
                            val activeColor = when (key) {
                                "DAILY" -> MonarchCyan
                                "MAIN" -> MonarchGold
                                "SIDE" -> MonarchPurpleLight
                                else -> MonarchCyan
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) activeColor.copy(alpha = 0.2f) else Color.Transparent)
                                    .border(
                                        width = if (isSelected) 1.dp else 0.dp,
                                        color = if (isSelected) activeColor else Color.Transparent,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .clickable { selectedTypeFilter = key }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSelected) activeColor else MonarchTextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Black else FontWeight.Medium,
                                    textAlign = TextAlign.Center,
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // SECTOR & STATUS CHIPS ROW
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Sector chips
                        val sectorFilters = listOf(
                            "ALL" to LanguageManager.getText("filter_all", isArabic),
                            "STUDY" to LanguageManager.getText("filter_study", isArabic),
                            "BUSINESS" to LanguageManager.getText("filter_business", isArabic),
                            "FITNESS" to LanguageManager.getText("filter_fitness", isArabic)
                        )

                        items(sectorFilters) { (key, label) ->
                            val isSelected = selectedSectorFilter == key
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (isSelected) MonarchCyan else MonarchFrameBgLight)
                                    .border(
                                        1.dp,
                                        if (isSelected) MonarchCyan else MonarchBorder,
                                        RoundedCornerShape(14.dp)
                                    )
                                    .clickable { selectedSectorFilter = key }
                                    .padding(horizontal = 12.dp, vertical = 5.dp)
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSelected) MonarchBg else MonarchTextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Status filter separator
                        item {
                            Box(
                                modifier = Modifier
                                    .width(1.dp)
                                    .height(24.dp)
                                    .background(MonarchBorder)
                            )
                        }

                        // Status filters: Active / Cleared
                        val statusFilters = listOf(
                            "ACTIVE" to LanguageManager.getText("status_pending", isArabic),
                            "CLEARED" to LanguageManager.getText("status_cleared", isArabic)
                        )

                        items(statusFilters) { (key, label) ->
                            val isSelected = selectedStatusFilter == key
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (isSelected) MonarchPurple else MonarchFrameBgLight)
                                    .border(
                                        1.dp,
                                        if (isSelected) MonarchPurpleLight else MonarchBorder,
                                        RoundedCornerShape(14.dp)
                                    )
                                    .clickable {
                                        selectedStatusFilter = if (selectedStatusFilter == key) "ALL" else key
                                    }
                                    .padding(horizontal = 12.dp, vertical = 5.dp)
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSelected) Color.White else MonarchTextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                }

                // EMPTY STATE
                if (filteredQuests.isEmpty()) {
                    item {
                        CyberpunkCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            borderColor = MonarchBorder
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Schedule,
                                    contentDescription = null,
                                    tint = MonarchTextMuted,
                                    modifier = Modifier.size(40.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (isArabic) "لا توجد مهام مطابقة في هذه المصفوفة" else "No quests found in this sector matrix",
                                    color = MonarchTextSecondary,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }

                // QUEST LIST ITEMS
                items(filteredQuests, key = { it.id }) { quest ->
                    QuestItemCard(
                        quest = quest,
                        isArabic = isArabic,
                        onToggleCheckbox = { newDoneState ->
                            onToggleQuestCompletion(quest, newDoneState)
                            if (newDoneState && !quest.isClaimed) {
                                val msg = if (isArabic) {
                                    "+${quest.xpReward} XP تم استلام المكافأة! [ انهض ]"
                                } else {
                                    "+${quest.xpReward} XP BOUNTY CLAIMED! [ ARISE ]"
                                }
                                toastMessage = msg
                            }
                        },
                        onStartTimer = { activeTimerQuest = quest },
                        onClaimOrComplete = {
                            onCompleteQuest(quest)
                            val msg = if (isArabic) {
                                "+${quest.xpReward} XP تم استلام المكافأة! [ انهض ]"
                            } else {
                                "+${quest.xpReward} XP BOUNTY CLAIMED! [ ARISE ]"
                            }
                            toastMessage = msg
                        },
                        onOpenReminder = {
                            requestNotificationPermissionIfNeeded()
                            reminderTargetQuest = quest
                        }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }

                item {
                    Spacer(modifier = Modifier.height(90.dp))
                }
            }

            // FLOATING CELEBRATION TOAST BANNER
            AnimatedVisibility(
                visible = toastMessage != null,
                enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 16.dp, start = 20.dp, end = 20.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MonarchFrameBg)
                        .border(1.5.dp, MonarchGold, RoundedCornerShape(12.dp))
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.ElectricBolt,
                            contentDescription = null,
                            tint = MonarchGold,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = toastMessage ?: "",
                            color = MonarchGold,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }

    // Active Quest Timer Dialog
    if (activeTimerQuest != null) {
        ActiveQuestTimerDialog(
            quest = activeTimerQuest!!,
            isArabic = isArabic,
            onDismiss = { activeTimerQuest = null },
            onTimerComplete = {
                val q = activeTimerQuest!!
                activeTimerQuest = null
                onTimerFinished(q)
                val msg = if (isArabic) {
                    "+${q.xpReward} XP تم إنهاء المؤقت واستلام المكافأة! [ انهض ]"
                } else {
                    "+${q.xpReward} XP TIMER CLEARED! [ ARISE ]"
                }
                toastMessage = msg
            }
        )
    }

    // Reminder Configuration Dialog
    if (reminderTargetQuest != null) {
        SetReminderDialog(
            quest = reminderTargetQuest!!,
            isArabic = isArabic,
            onDismiss = { reminderTargetQuest = null },
            onSetReminder = { triggerMillis ->
                val q = reminderTargetQuest!!
                reminderTargetQuest = null
                onToggleReminder(q, true, triggerMillis)
                val msg = LanguageManager.getText("reminder_set_success", isArabic)
                toastMessage = msg
            },
            onCancelReminder = {
                val q = reminderTargetQuest!!
                reminderTargetQuest = null
                onToggleReminder(q, false, 0L)
            }
        )
    }

    // Create Quest Dialog
    if (showCreateQuestDialog) {
        CreateQuestDialog(
            isArabic = isArabic,
            onDismiss = { showCreateQuestDialog = false },
            onCreate = { newQuest ->
                onAddQuest(newQuest)
                showCreateQuestDialog = false
            }
        )
    }

    // Level-Up Celebration Dialog
    if (showLevelUpPopup != null) {
        val (lvl, rank) = showLevelUpPopup!!
        LevelUpDialog(
            level = lvl,
            rank = rank,
            isArabic = isArabic,
            onDismiss = { showLevelUpPopup = null }
        )
    }
}

@Composable
fun QuestItemCard(
    quest: Quest,
    isArabic: Boolean,
    onToggleCheckbox: (Boolean) -> Unit,
    onStartTimer: () -> Unit,
    onClaimOrComplete: () -> Unit,
    onOpenReminder: () -> Unit
) {
    val title = if (isArabic) quest.titleAr else quest.title
    val description = if (isArabic) quest.descriptionAr else quest.description

    // Type badge color and styling
    val typeBadgeColor = quest.questType.badgeColor
    val typeName = if (isArabic) quest.questType.nameAr else quest.questType.nameEn

    CyberpunkCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("quest_card_${quest.id}"),
        borderColor = if (quest.isCompleted) MonarchBorder else MonarchBorderCyan,
        backgroundColor = if (quest.isCompleted) MonarchFrameBg.copy(alpha = 0.55f) else MonarchFrameBg
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            // CHECKABLE CHECKBOX (Custom Solo Leveling Cybernetic Box)
            Box(
                modifier = Modifier
                    .padding(top = 2.dp, end = 12.dp)
                    .size(28.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        if (quest.isCompleted) MonarchCyan.copy(alpha = 0.25f)
                        else MonarchFrameBgLight
                    )
                    .border(
                        width = if (quest.isCompleted) 1.5.dp else 1.dp,
                        color = if (quest.isCompleted) MonarchCyan else MonarchBorder,
                        shape = RoundedCornerShape(6.dp)
                    )
                    .clickable {
                        onToggleCheckbox(!quest.isCompleted)
                    }
                    .testTag("quest_checkbox_${quest.id}"),
                contentAlignment = Alignment.Center
            ) {
                if (quest.isCompleted) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Completed",
                        tint = MonarchCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // MAIN CONTENT COLUMN
            Column(modifier = Modifier.weight(1f)) {
                // Top Tag Bar: Type Badge, Sector, Rank, Due Time, XP
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Quest Type Badge (Daily, Main, Side)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(typeBadgeColor.copy(alpha = 0.15f))
                            .border(1.dp, typeBadgeColor, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = typeName.uppercase(),
                            color = typeBadgeColor,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Sector tag
                    Text(
                        text = if (isArabic) quest.sector.nameAr else quest.sector.nameEn.substringBefore(" &"),
                        color = quest.sector.color,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    // Difficulty Rank
                    Box(
                        modifier = Modifier
                            .background(MonarchBorder, RoundedCornerShape(4.dp))
                            .padding(horizontal = 5.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "RANK ${quest.rank}",
                            color = MonarchTextSecondary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    // XP Bounty
                    Text(
                        text = "+${quest.xpReward} XP",
                        color = MonarchGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Title
                Text(
                    text = title,
                    color = if (quest.isCompleted) MonarchTextMuted else MonarchTextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    textDecoration = if (quest.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                )

                if (description.isNotBlank()) {
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = description,
                        color = if (quest.isCompleted) MonarchTextMuted else MonarchTextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Metadata Row: Due Time & Reminder Bell
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Due Time indicator
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = null,
                            tint = if (quest.reminderEnabled) MonarchCyan else MonarchTextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${LanguageManager.getText("due_label", isArabic)}: ${quest.dueTime.ifBlank { "20:00" }}",
                            color = if (quest.reminderEnabled) MonarchCyan else MonarchTextSecondary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (quest.reminderEnabled) FontWeight.Bold else FontWeight.Normal
                        )
                    }

                    // Reminder Button
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                if (quest.reminderEnabled) MonarchCyan.copy(alpha = 0.15f)
                                else MonarchFrameBgLight
                            )
                            .border(
                                width = 1.dp,
                                color = if (quest.reminderEnabled) MonarchCyan else MonarchBorder,
                                shape = RoundedCornerShape(6.dp)
                            )
                            .clickable { onOpenReminder() }
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (quest.reminderEnabled) Icons.Default.NotificationsActive else Icons.Default.Notifications,
                                contentDescription = "Reminder",
                                tint = if (quest.reminderEnabled) MonarchCyan else MonarchTextSecondary,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (quest.reminderEnabled) LanguageManager.getText("reminder_set", isArabic)
                                else LanguageManager.getText("remind_me", isArabic),
                                color = if (quest.reminderEnabled) MonarchCyan else MonarchTextSecondary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Bottom Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Timer duration indicator
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = null,
                            tint = MonarchCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${quest.durationMinutes} ${LanguageManager.getText("min", isArabic)}",
                            color = MonarchCyan,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (!quest.isCompleted) {
                            // Start Countdown Timer
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MonarchCyan.copy(alpha = 0.15f))
                                    .border(1.dp, MonarchCyan, RoundedCornerShape(6.dp))
                                    .clickable { onStartTimer() }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        tint = MonarchCyan,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = LanguageManager.getText("start_timer", isArabic),
                                        color = MonarchCyan,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // Complete Action Button
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MonarchGreen.copy(alpha = 0.15f))
                                    .border(1.dp, MonarchGreen, RoundedCornerShape(6.dp))
                                    .clickable { onClaimOrComplete() }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = MonarchGreen,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = LanguageManager.getText("complete_quest", isArabic),
                                        color = MonarchGreen,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        } else if (!quest.isClaimed) {
                            // Completed but not claimed: Glowing Claim XP button
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MonarchGold.copy(alpha = 0.25f))
                                    .border(1.5.dp, MonarchGold, RoundedCornerShape(6.dp))
                                    .clickable { onClaimOrComplete() }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.ElectricBolt,
                                        contentDescription = null,
                                        tint = MonarchGold,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${LanguageManager.getText("claim_xp", isArabic)} (+${quest.xpReward} XP)",
                                        color = MonarchGold,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        } else {
                            // Completed and claimed
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MonarchBorder)
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "✓ " + LanguageManager.getText("claimed", isArabic),
                                    color = MonarchGreen,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SetReminderDialog(
    quest: Quest,
    isArabic: Boolean,
    onDismiss: () -> Unit,
    onSetReminder: (triggerMillis: Long) -> Unit,
    onCancelReminder: () -> Unit
) {
    val title = if (isArabic) quest.titleAr else quest.title

    Dialog(onDismissRequest = onDismiss) {
        CyberpunkCard(
            modifier = Modifier.fillMaxWidth(),
            borderColor = MonarchCyan,
            borderWidth = 1.5.dp
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = LanguageManager.getText("set_reminder", isArabic),
                        color = MonarchCyan,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = MonarchTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = title,
                    color = MonarchTextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "${LanguageManager.getText("due_label", isArabic)}: ${quest.dueTime.ifBlank { "20:00" }}",
                    color = MonarchGold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = if (isArabic) "اختر موعد إرسال إشعار التذكير:" else "Choose reminder trigger time:",
                    color = MonarchTextSecondary,
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Presets: +15 min, +30 min, +1 hour
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val presets = listOf(
                        LanguageManager.getText("remind_in_15", isArabic) to 15 * 60 * 1000L,
                        LanguageManager.getText("remind_in_30", isArabic) to 30 * 60 * 1000L,
                        LanguageManager.getText("remind_in_60", isArabic) to 60 * 60 * 1000L
                    )

                    presets.forEach { (label, offsetMillis) ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MonarchCyan.copy(alpha = 0.15f))
                                .border(1.dp, MonarchCyan, RoundedCornerShape(8.dp))
                                .clickable {
                                    val target = System.currentTimeMillis() + offsetMillis
                                    onSetReminder(target)
                                }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                color = MonarchCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Trigger in 1 minute (for quick test)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MonarchPurple.copy(alpha = 0.2f))
                        .border(1.dp, MonarchPurpleLight, RoundedCornerShape(8.dp))
                        .clickable {
                            val target = System.currentTimeMillis() + 60 * 1000L
                            onSetReminder(target)
                        }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isArabic) "⚡ تنبيه سريع (خلال دقيقة واحدة)" else "⚡ Quick Test Alert (In 1 minute)",
                        color = MonarchPurpleLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (quest.reminderEnabled) {
                    Spacer(modifier = Modifier.height(12.dp))
                    CyberpunkButton(
                        text = if (isArabic) "إلغاء التذكير النشط" else "CANCEL ACTIVE REMINDER",
                        onClick = onCancelReminder,
                        modifier = Modifier.fillMaxWidth(),
                        isPrimary = false,
                        color = MonarchRed
                    )
                }
            }
        }
    }
}

@Composable
fun CreateQuestDialog(
    isArabic: Boolean,
    onDismiss: () -> Unit,
    onCreate: (Quest) -> Unit
) {
    var selectedType by remember { mutableStateOf(QuestType.DAILY) }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var dueTimeText by remember { mutableStateOf("Today 20:00") }
    var durationText by remember { mutableStateOf("25") }
    var xpText by remember { mutableStateOf("60") }
    var selectedSector by remember { mutableStateOf(SectorType.STUDY) }
    var selectedRank by remember { mutableStateOf("E") }
    var enableReminder by remember { mutableStateOf(true) }

    val ranks = listOf("E", "D", "C", "B", "A", "S")

    Dialog(onDismissRequest = onDismiss) {
        CyberpunkCard(
            modifier = Modifier.fillMaxWidth(),
            borderColor = MonarchCyan,
            borderWidth = 1.5.dp
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = LanguageManager.getText("new_quest", isArabic),
                        color = MonarchCyan,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = MonarchTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // QUEST TYPE SELECTOR (Daily, Main, Side)
                Text(
                    text = LanguageManager.getText("quest_type_label", isArabic),
                    color = MonarchTextSecondary,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    QuestType.entries.forEach { type ->
                        val isSelected = selectedType == type
                        val color = type.badgeColor
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) color.copy(alpha = 0.25f) else MonarchFrameBgLight)
                                .border(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) color else MonarchBorder,
                                    shape = RoundedCornerShape(6.dp)
                                )
                                .clickable {
                                    selectedType = type
                                    // Set sensible defaults for quest type
                                    when (type) {
                                        QuestType.DAILY -> {
                                            durationText = "25"
                                            xpText = "60"
                                            dueTimeText = "Today 21:00"
                                        }
                                        QuestType.MAIN -> {
                                            durationText = "45"
                                            xpText = "120"
                                            dueTimeText = "Today 18:00"
                                        }
                                        QuestType.SIDE -> {
                                            durationText = "20"
                                            xpText = "45"
                                            dueTimeText = "Today 23:00"
                                        }
                                    }
                                }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (isArabic) type.nameAr else type.nameEn,
                                color = if (isSelected) color else MonarchTextSecondary,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                                maxLines = 1
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Quest Title
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text(LanguageManager.getText("quest_title", isArabic)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("new_quest_title_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MonarchCyan,
                        unfocusedBorderColor = MonarchBorder,
                        focusedTextColor = MonarchTextPrimary,
                        unfocusedTextColor = MonarchTextPrimary
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Quest Description
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text(LanguageManager.getText("quest_desc", isArabic)) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MonarchCyan,
                        unfocusedBorderColor = MonarchBorder,
                        focusedTextColor = MonarchTextPrimary,
                        unfocusedTextColor = MonarchTextPrimary
                    ),
                    maxLines = 2
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Sector selection chips
                Text(
                    text = if (isArabic) "القطاع:" else "Sector:",
                    color = MonarchTextSecondary,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    SectorType.entries.forEach { sector ->
                        val isSelected = selectedSector == sector
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) sector.color else MonarchFrameBg)
                                .border(1.dp, sector.color, RoundedCornerShape(6.dp))
                                .clickable { selectedSector = sector }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (isArabic) sector.nameAr else sector.nameEn.substringBefore(" &"),
                                color = if (isSelected) MonarchBg else MonarchTextPrimary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Difficulty Rank Selection
                Text(
                    text = if (isArabic) "رتبة الصعوبة:" else "Quest Difficulty Rank:",
                    color = MonarchTextSecondary,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    ranks.forEach { rank ->
                        val isSelected = selectedRank == rank
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) MonarchPurple else MonarchFrameBg)
                                .border(1.dp, if (isSelected) MonarchCyan else MonarchBorder, RoundedCornerShape(6.dp))
                                .clickable {
                                    selectedRank = rank
                                    xpText = when (rank) {
                                        "E" -> "50"
                                        "D" -> "75"
                                        "C" -> "100"
                                        "B" -> "150"
                                        "A" -> "220"
                                        else -> "350"
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = rank,
                                color = if (isSelected) Color.White else MonarchTextSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Due Time Input & Suggestions
                OutlinedTextField(
                    value = dueTimeText,
                    onValueChange = { dueTimeText = it },
                    label = { Text(LanguageManager.getText("due_time", isArabic)) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MonarchCyan,
                        unfocusedBorderColor = MonarchBorder,
                        focusedTextColor = MonarchTextPrimary,
                        unfocusedTextColor = MonarchTextPrimary
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Duration & XP Bounty
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = durationText,
                        onValueChange = { durationText = it.filter { ch -> ch.isDigit() } },
                        label = { Text(LanguageManager.getText("duration", isArabic)) },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MonarchCyan,
                            unfocusedBorderColor = MonarchBorder,
                            focusedTextColor = MonarchTextPrimary,
                            unfocusedTextColor = MonarchTextPrimary
                        ),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = xpText,
                        onValueChange = { xpText = it.filter { ch -> ch.isDigit() } },
                        label = { Text(LanguageManager.getText("xp_reward", isArabic)) },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MonarchCyan,
                            unfocusedBorderColor = MonarchBorder,
                            focusedTextColor = MonarchTextPrimary,
                            unfocusedTextColor = MonarchTextPrimary
                        ),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Reminder Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = LanguageManager.getText("enable_reminder", isArabic),
                        color = MonarchTextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Switch(
                        checked = enableReminder,
                        onCheckedChange = { enableReminder = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MonarchCyan,
                            checkedTrackColor = MonarchCyan.copy(alpha = 0.3f),
                            uncheckedThumbColor = MonarchTextMuted,
                            uncheckedTrackColor = MonarchFrameBgLight
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                CyberpunkButton(
                    text = LanguageManager.getText("create_quest_btn", isArabic),
                    onClick = {
                        val duration = durationText.toIntOrNull() ?: 25
                        val xp = xpText.toIntOrNull() ?: 50
                        val reminderTarget = if (enableReminder) System.currentTimeMillis() + 30 * 60 * 1000L else 0L
                        val newQ = Quest(
                            id = "quest_${System.currentTimeMillis()}",
                            title = title.ifBlank { "Daily Hunter Quest" },
                            titleAr = title.ifBlank { "مهمة الصياد اليومية" },
                            description = description,
                            descriptionAr = description,
                            sector = selectedSector,
                            rank = selectedRank,
                            durationMinutes = duration,
                            xpReward = xp,
                            isCompleted = false,
                            isClaimed = false,
                            questType = selectedType,
                            isDaily = selectedType == QuestType.DAILY,
                            dueTime = dueTimeText.ifBlank { "Today 20:00" },
                            reminderEnabled = enableReminder,
                            reminderTimestamp = reminderTarget
                        )
                        onCreate(newQ)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("submit_create_quest_button"),
                    isPrimary = true
                )
            }
        }
    }
}

@Composable
fun ActiveQuestTimerDialog(
    quest: Quest,
    isArabic: Boolean,
    onDismiss: () -> Unit,
    onTimerComplete: () -> Unit
) {
    val totalSeconds = quest.durationMinutes * 60
    var secondsRemaining by remember { mutableIntStateOf(totalSeconds) }
    var isRunning by remember { mutableStateOf(true) }

    LaunchedEffect(isRunning, secondsRemaining) {
        if (isRunning && secondsRemaining > 0) {
            delay(1000)
            secondsRemaining--
        } else if (secondsRemaining <= 0) {
            onTimerComplete()
        }
    }

    val minutes = secondsRemaining / 60
    val seconds = secondsRemaining % 60
    val formattedTime = String.format("%02d:%02d", minutes, seconds)
    val progress = if (totalSeconds > 0) secondsRemaining.toFloat() / totalSeconds.toFloat() else 0f

    val title = if (isArabic) quest.titleAr else quest.title

    Dialog(onDismissRequest = onDismiss) {
        CyberpunkCard(
            modifier = Modifier.fillMaxWidth(),
            borderColor = MonarchCyan,
            borderWidth = 2.dp,
            backgroundColor = MonarchFrameBg
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = LanguageManager.getText("active_timer", isArabic),
                        color = MonarchCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = MonarchTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = title,
                    color = MonarchTextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Circular Progress Indicator
                Box(
                    modifier = Modifier.size(170.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        progress = { 1f - progress },
                        modifier = Modifier.fillMaxSize(),
                        color = MonarchCyan,
                        trackColor = MonarchBorder,
                        strokeWidth = 10.dp
                    )

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = formattedTime,
                            color = MonarchCyan,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "+${quest.xpReward} XP",
                            color = MonarchGold,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Timer Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MonarchFrameBgLight)
                            .border(1.dp, MonarchBorder, RoundedCornerShape(8.dp))
                            .clickable { secondsRemaining = totalSeconds }
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Refresh, contentDescription = null, tint = MonarchTextSecondary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(LanguageManager.getText("reset", isArabic), color = MonarchTextSecondary, fontSize = 12.sp)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isRunning) MonarchPurple.copy(alpha = 0.2f) else MonarchCyan.copy(alpha = 0.2f))
                            .border(1.dp, if (isRunning) MonarchPurpleLight else MonarchCyan, RoundedCornerShape(8.dp))
                            .clickable { isRunning = !isRunning }
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = if (isRunning) MonarchPurpleLight else MonarchCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isRunning) LanguageManager.getText("pause", isArabic) else LanguageManager.getText("resume", isArabic),
                                color = if (isRunning) MonarchPurpleLight else MonarchCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MonarchGreen.copy(alpha = 0.2f))
                            .border(1.dp, MonarchGreen, RoundedCornerShape(8.dp))
                            .clickable { onTimerComplete() }
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = LanguageManager.getText("finish_early", isArabic),
                            color = MonarchGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LevelUpDialog(
    level: Int,
    rank: HunterRank,
    isArabic: Boolean,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        CyberpunkCard(
            modifier = Modifier.fillMaxWidth(),
            borderColor = MonarchGold,
            borderWidth = 2.dp,
            backgroundColor = MonarchFrameBg
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = LanguageManager.getText("level_up_title", isArabic),
                    color = MonarchGold,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "LEVEL $level",
                    color = MonarchCyan,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(6.dp))

                HunterRankBadge(rank = rank, isArabic = isArabic)

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = LanguageManager.getText("level_up_body", isArabic),
                    color = MonarchTextSecondary,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(20.dp))

                CyberpunkButton(
                    text = LanguageManager.getText("claim_level", isArabic),
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("claim_level_button"),
                    isPrimary = true,
                    color = MonarchGold
                )
            }
        }
    }
}
