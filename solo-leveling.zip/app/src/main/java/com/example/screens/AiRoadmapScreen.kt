package com.example.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.components.CyberpunkButton
import com.example.components.CyberpunkCard
import com.example.components.JinWooMentorCard
import com.example.components.LanguageToggleButton
import com.example.models.Quest
import com.example.models.RoadmapPhase
import com.example.ui.theme.MonarchBg
import com.example.ui.theme.MonarchBorder
import com.example.ui.theme.MonarchBorderCyan
import com.example.ui.theme.MonarchCyan
import com.example.ui.theme.MonarchFrameBg
import com.example.ui.theme.MonarchFrameBgLight
import com.example.ui.theme.MonarchGold
import com.example.ui.theme.MonarchGreen
import com.example.ui.theme.MonarchPurple
import com.example.ui.theme.MonarchPurpleLight
import com.example.ui.theme.MonarchTextPrimary
import com.example.ui.theme.MonarchTextSecondary
import com.example.util.GeminiRoadmapGenerator
import com.example.util.LanguageManager
import kotlinx.coroutines.launch

@Composable
fun AiRoadmapScreen(
    language: String,
    onLanguageChange: (String) -> Unit,
    onBack: () -> Unit,
    onImportQuestsToMatrix: (List<Quest>) -> Unit
) {
    val isArabic = language == "ar"
    val coroutineScope = rememberCoroutineScope()

    var projectName by remember { mutableStateOf("Shadow Sovereign AI") }
    var projectDescription by remember {
        mutableStateOf("A high-tech SaaS automation platform that scales business pipelines automatically.")
    }
    var isLoading by remember { mutableStateOf(false) }
    var roadmapPhases by remember { mutableStateOf<List<RoadmapPhase>>(emptyList()) }
    var isImported by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MonarchBg)
            .padding(horizontal = 20.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Spacer(modifier = Modifier.height(24.dp))

        // Top bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(40.dp)
                    .background(MonarchFrameBgLight, RoundedCornerShape(8.dp))
                    .border(1.dp, MonarchBorder, RoundedCornerShape(8.dp))
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = MonarchCyan
                )
            }

            LanguageToggleButton(
                currentLanguage = language,
                onLanguageToggle = onLanguageChange
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = MonarchCyan,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = LanguageManager.getText("ai_business_title", isArabic),
                color = MonarchTextPrimary,
                fontSize = 22.sp,
                fontWeight = FontWeight.Black
            )
        }

        Text(
            text = LanguageManager.getText("ai_business_sub", isArabic),
            color = MonarchTextSecondary,
            fontSize = 13.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Sung Jin-Woo Mentor
        JinWooMentorCard(
            dialogueText = LanguageManager.getText("mentor_roadmap", isArabic),
            isArabic = isArabic
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Input Card
        CyberpunkCard(
            modifier = Modifier.fillMaxWidth(),
            borderColor = MonarchBorderCyan
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                OutlinedTextField(
                    value = projectName,
                    onValueChange = { projectName = it },
                    label = { Text(LanguageManager.getText("project_name", isArabic)) },
                    leadingIcon = {
                        Icon(Icons.Default.BusinessCenter, contentDescription = null, tint = MonarchCyan)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("project_name_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MonarchCyan,
                        unfocusedBorderColor = MonarchBorder,
                        focusedLabelColor = MonarchCyan,
                        focusedTextColor = MonarchTextPrimary,
                        unfocusedTextColor = MonarchTextPrimary,
                        cursorColor = MonarchCyan,
                        focusedContainerColor = MonarchFrameBgLight,
                        unfocusedContainerColor = MonarchFrameBg
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = projectDescription,
                    onValueChange = { projectDescription = it },
                    label = { Text(LanguageManager.getText("project_desc", isArabic)) },
                    leadingIcon = {
                        Icon(Icons.Default.Description, contentDescription = null, tint = MonarchCyan)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .testTag("project_desc_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MonarchCyan,
                        unfocusedBorderColor = MonarchBorder,
                        focusedLabelColor = MonarchCyan,
                        focusedTextColor = MonarchTextPrimary,
                        unfocusedTextColor = MonarchTextPrimary,
                        cursorColor = MonarchCyan,
                        focusedContainerColor = MonarchFrameBgLight,
                        unfocusedContainerColor = MonarchFrameBg
                    ),
                    maxLines = 4
                )

                Spacer(modifier = Modifier.height(16.dp))

                CyberpunkButton(
                    text = if (isLoading) LanguageManager.getText("generating", isArabic) else LanguageManager.getText("generate_roadmap", isArabic),
                    onClick = {
                        isLoading = true
                        isImported = false
                        coroutineScope.launch {
                            val result = GeminiRoadmapGenerator.generateRoadmap(
                                projectName = projectName,
                                projectDescription = projectDescription,
                                isArabic = isArabic
                            )
                            roadmapPhases = result
                            isLoading = false
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("generate_roadmap_button"),
                    enabled = !isLoading,
                    isPrimary = true
                )
            }
        }

        if (isLoading) {
            Spacer(modifier = Modifier.height(30.dp))
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator(color = MonarchCyan)
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = LanguageManager.getText("generating", isArabic),
                    color = MonarchCyan,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Render Generated 5-Phase Roadmap
        if (roadmapPhases.isNotEmpty()) {
            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = if (isArabic) "خارطة الطريق الخماسية المستخرجة" else "5-PHASE TACTICAL ROADMAP",
                color = MonarchCyan,
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            roadmapPhases.forEach { phase ->
                val phaseName = if (isArabic) phase.nameAr else phase.nameEn
                val objective = if (isArabic) phase.objectiveAr else phase.objectiveEn

                CyberpunkCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    borderColor = MonarchPurpleLight.copy(alpha = 0.5f),
                    backgroundColor = MonarchFrameBgLight
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MonarchPurple),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${phase.phaseNumber}",
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = phaseName,
                                color = MonarchTextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = objective,
                            color = MonarchTextSecondary,
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Quests under this phase
                        phase.suggestedQuests.forEach { q ->
                            val qTitle = if (isArabic) q.titleAr else q.title
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MonarchBg, RoundedCornerShape(6.dp))
                                    .border(1.dp, MonarchBorder, RoundedCornerShape(6.dp))
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "⚔️ $qTitle",
                                    color = MonarchTextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.weight(1f)
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Timer,
                                        contentDescription = null,
                                        tint = MonarchCyan,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text(
                                        text = "${q.durationMinutes}m",
                                        color = MonarchCyan,
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "+${q.xpReward} XP",
                                        color = MonarchGold,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Import Quests Button
            val allQuests = roadmapPhases.flatMap { it.suggestedQuests }

            if (!isImported) {
                CyberpunkButton(
                    text = "📥 " + LanguageManager.getText("import_quests", isArabic),
                    onClick = {
                        onImportQuestsToMatrix(allQuests)
                        isImported = true
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("import_quests_button"),
                    isPrimary = true,
                    color = MonarchGreen
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MonarchGreen.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                        .border(1.dp, MonarchGreen, RoundedCornerShape(8.dp))
                        .padding(14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = MonarchGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = LanguageManager.getText("quests_imported", isArabic),
                            color = MonarchGreen,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}
