package com.example.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.components.AriseButton
import com.example.components.JinWooMentorCard
import com.example.components.LanguageToggleButton
import com.example.ui.theme.MonarchBg
import com.example.ui.theme.MonarchBorderCyan
import com.example.ui.theme.MonarchCyan
import com.example.ui.theme.MonarchFrameBgLight
import com.example.ui.theme.MonarchPurple
import com.example.ui.theme.MonarchPurpleLight
import com.example.ui.theme.MonarchTextPrimary
import com.example.ui.theme.MonarchTextSecondary
import com.example.util.LanguageManager
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    language: String,
    onLanguageChange: (String) -> Unit,
    onInitializeComplete: () -> Unit,
    onPlaySound: () -> Unit
) {
    val isArabic = language == "ar"
    var progress by remember { mutableFloatStateOf(0f) }
    var currentStep by remember { mutableIntStateOf(1) }
    var isReadyToArise by remember { mutableStateOf(false) }

    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(400),
        label = "boot_progress"
    )

    LaunchedEffect(Unit) {
        delay(300)
        progress = 0.20f
        currentStep = 1
        delay(600)
        progress = 0.45f
        currentStep = 2
        delay(600)
        progress = 0.70f
        currentStep = 3
        delay(600)
        progress = 0.90f
        currentStep = 4
        delay(600)
        progress = 1.0f
        currentStep = 5
        delay(400)
        isReadyToArise = true
    }

    val stepText = when (currentStep) {
        1 -> LanguageManager.getText("boot_step_1", isArabic)
        2 -> LanguageManager.getText("boot_step_2", isArabic)
        3 -> LanguageManager.getText("boot_step_3", isArabic)
        4 -> LanguageManager.getText("boot_step_4", isArabic)
        else -> LanguageManager.getText("boot_step_5", isArabic)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MonarchBg)
            .padding(20.dp)
    ) {
        // Language Toggle at top right
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp),
            horizontalArrangement = Arrangement.End
        ) {
            LanguageToggleButton(
                currentLanguage = language,
                onLanguageToggle = onLanguageChange
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(vertical = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Shadow Monarch Emblem / Avatar
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .clip(CircleShape)
                    .border(
                        width = 2.5.dp,
                        brush = Brush.sweepGradient(listOf(MonarchCyan, MonarchPurpleLight, MonarchCyan)),
                        shape = CircleShape
                    )
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_app_icon),
                    contentDescription = "Monarch Emblem",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // System Notification header
            Box(
                modifier = Modifier
                    .background(MonarchPurple.copy(alpha = 0.25f), RoundedCornerShape(4.dp))
                    .border(1.dp, MonarchPurpleLight.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            ) {
                Text(
                    text = LanguageManager.getText("system_title", isArabic),
                    color = MonarchPurpleLight,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = LanguageManager.getText("app_title", isArabic),
                color = MonarchTextPrimary,
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 3.sp,
                fontFamily = FontFamily.Monospace
            )

            Text(
                text = LanguageManager.getText("arise_tagline", isArabic),
                color = MonarchCyan,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(36.dp))

            // Progress Bar (0% to 100%)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = LanguageManager.getText("initializing", isArabic),
                        color = MonarchCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "${(animatedProgress * 100).toInt()}%",
                        color = MonarchCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                LinearProgressIndicator(
                    progress = { animatedProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .border(1.dp, MonarchBorderCyan.copy(alpha = 0.4f), RoundedCornerShape(5.dp)),
                    color = MonarchCyan,
                    trackColor = MonarchFrameBgLight,
                    strokeCap = StrokeCap.Round
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "> $stepText",
                    color = MonarchTextSecondary,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Interactive Sung Jin-Woo Mentor Card
            JinWooMentorCard(
                dialogueText = LanguageManager.getText("mentor_splash", isArabic),
                isArabic = isArabic,
                modifier = Modifier.padding(horizontal = 8.dp)
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Signature [ ARISE ] Trigger Button
            AnimatedVisibility(
                visible = isReadyToArise,
                enter = fadeIn(tween(500))
            ) {
                AriseButton(
                    text = "[ " + LanguageManager.getText("arise", isArabic) + " ]",
                    onClick = {
                        onPlaySound()
                        onInitializeComplete()
                    }
                )
            }
        }
    }
}
