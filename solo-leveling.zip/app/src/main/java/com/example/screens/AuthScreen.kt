package com.example.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.components.CyberpunkButton
import com.example.components.CyberpunkCard
import com.example.components.JinWooMentorCard
import com.example.components.LanguageToggleButton
import com.example.models.HunterProfile
import com.example.ui.theme.MonarchBg
import com.example.ui.theme.MonarchBorder
import com.example.ui.theme.MonarchCyan
import com.example.ui.theme.MonarchFrameBg
import com.example.ui.theme.MonarchFrameBgLight
import com.example.ui.theme.MonarchPurple
import com.example.ui.theme.MonarchPurpleLight
import com.example.ui.theme.MonarchTextPrimary
import com.example.ui.theme.MonarchTextSecondary
import com.example.util.LanguageManager

@Composable
fun AuthScreen(
    currentProfile: HunterProfile,
    language: String,
    onLanguageChange: (String) -> Unit,
    onAuthSuccess: (HunterProfile) -> Unit
) {
    val isArabic = language == "ar"
    var isSignUp by remember { mutableStateOf(true) }

    var fullName by remember { mutableStateOf(currentProfile.fullName) }
    var email by remember { mutableStateOf(currentProfile.email) }
    var password by remember { mutableStateOf("shadowmonarch123") }
    var ageText by remember { mutableStateOf(currentProfile.age.toString()) }
    var selectedAvatar by remember { mutableStateOf(currentProfile.avatarId) }
    var passwordVisible by remember { mutableStateOf(false) }

    val avatars = listOf(
        "img_jinwoo_mentor" to R.drawable.img_jinwoo_mentor,
        "img_avatar_shadow" to R.drawable.img_avatar_shadow,
        "img_avatar_mage" to R.drawable.img_avatar_mage
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MonarchBg)
            .padding(horizontal = 20.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Spacer(modifier = Modifier.height(24.dp))

        // Top bar with language switch
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .background(MonarchPurple.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                    .border(1.dp, MonarchPurple.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "HUNTER REGISTRATION GATE",
                    color = MonarchCyan,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            LanguageToggleButton(
                currentLanguage = language,
                onLanguageToggle = onLanguageChange
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = LanguageManager.getText(if (isSignUp) "auth_title_signup" else "auth_title_login", isArabic),
            color = MonarchTextPrimary,
            fontSize = 24.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp
        )

        Text(
            text = LanguageManager.getText("auth_sub", isArabic),
            color = MonarchTextSecondary,
            fontSize = 13.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Sung Jin-Woo Mentor Guidance
        JinWooMentorCard(
            dialogueText = LanguageManager.getText("mentor_auth", isArabic),
            isArabic = isArabic
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Avatar Selection
        if (isSignUp) {
            Text(
                text = LanguageManager.getText("select_avatar", isArabic),
                color = MonarchCyan,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                avatars.forEach { (avatarId, drawableRes) ->
                    val isSelected = selectedAvatar == avatarId
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .border(
                                width = if (isSelected) 3.dp else 1.dp,
                                color = if (isSelected) MonarchCyan else MonarchBorder,
                                shape = CircleShape
                            )
                            .clickable { selectedAvatar = avatarId }
                            .padding(if (isSelected) 2.dp else 0.dp)
                    ) {
                        Image(
                            painter = painterResource(id = drawableRes),
                            contentDescription = "Avatar $avatarId",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Form Fields
        CyberpunkCard(
            modifier = Modifier.fillMaxWidth(),
            borderColor = MonarchBorder
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                if (isSignUp) {
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text(LanguageManager.getText("full_name", isArabic)) },
                        leadingIcon = {
                            Icon(Icons.Default.Person, contentDescription = null, tint = MonarchCyan)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("full_name_input"),
                        colors = outlinedFieldColors(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text(LanguageManager.getText("email", isArabic)) },
                    leadingIcon = {
                        Icon(Icons.Default.Email, contentDescription = null, tint = MonarchCyan)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("email_input"),
                    colors = outlinedFieldColors(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text(LanguageManager.getText("password", isArabic)) },
                    leadingIcon = {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = MonarchCyan)
                    },
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = "Toggle password",
                                tint = MonarchTextSecondary
                            )
                        }
                    },
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("password_input"),
                    colors = outlinedFieldColors(),
                    singleLine = true
                )

                if (isSignUp) {
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = ageText,
                        onValueChange = { ageText = it.filter { ch -> ch.isDigit() }.take(3) },
                        label = { Text(LanguageManager.getText("age", isArabic)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("age_input"),
                        colors = outlinedFieldColors(),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Primary Action Button
                CyberpunkButton(
                    text = LanguageManager.getText(if (isSignUp) "btn_signup" else "btn_login", isArabic),
                    onClick = {
                        val parsedAge = ageText.toIntOrNull() ?: 20
                        val updated = currentProfile.copy(
                            fullName = fullName.ifBlank { "Hunter Sung" },
                            email = email.ifBlank { "hunter@monarch.system" },
                            age = parsedAge,
                            avatarId = selectedAvatar,
                            isLoggedIn = true
                        )
                        onAuthSuccess(updated)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("auth_submit_button"),
                    isPrimary = true
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Toggle between sign up and login
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    TextButton(onClick = { isSignUp = !isSignUp }) {
                        Text(
                            text = LanguageManager.getText(if (isSignUp) "toggle_login" else "toggle_signup", isArabic),
                            color = MonarchCyan,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Google OAuth Sign-In option
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            HorizontalDivider(modifier = Modifier.weight(1f), color = MonarchBorder)
            Text(
                text = " OR ",
                color = MonarchTextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 8.dp)
            )
            HorizontalDivider(modifier = Modifier.weight(1f), color = MonarchBorder)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Google OAuth Button
        CyberpunkButton(
            text = "⚡ " + LanguageManager.getText("google_signin", isArabic),
            onClick = {
                val updated = currentProfile.copy(
                    fullName = "Hunter Jin-Woo (Google)",
                    email = "hunter.google@monarch.system",
                    isLoggedIn = true
                )
                onAuthSuccess(updated)
            },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("google_signin_button"),
            isPrimary = false,
            color = MonarchPurpleLight
        )

        Spacer(modifier = Modifier.height(30.dp))
    }
}

@Composable
private fun outlinedFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = MonarchCyan,
    unfocusedBorderColor = MonarchBorder,
    focusedLabelColor = MonarchCyan,
    unfocusedLabelColor = MonarchTextSecondary,
    focusedTextColor = MonarchTextPrimary,
    unfocusedTextColor = MonarchTextPrimary,
    cursorColor = MonarchCyan,
    focusedContainerColor = MonarchFrameBgLight,
    unfocusedContainerColor = MonarchFrameBg
)
