package com.example.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.components.AriseButton
import com.example.components.CyberpunkCard
import com.example.components.HunterRankBadge
import com.example.components.JinWooMentorCard
import com.example.components.LanguageToggleButton
import com.example.models.HunterProfile
import com.example.models.SectorType
import com.example.ui.theme.MonarchBg
import com.example.ui.theme.MonarchBorder
import com.example.ui.theme.MonarchCyan
import com.example.ui.theme.MonarchFrameBg
import com.example.ui.theme.MonarchFrameBgLight
import com.example.ui.theme.MonarchPurple
import com.example.ui.theme.MonarchPurpleLight
import com.example.ui.theme.MonarchTextPrimary
import com.example.ui.theme.MonarchTextSecondary
import com.example.util.LanguageManager

@Composable
fun AriseScreen(
    profile: HunterProfile,
    language: String,
    onLanguageChange: (String) -> Unit,
    onEnterDashboard: () -> Unit,
    onPlayAriseSound: () -> Unit
) {
    val isArabic = language == "ar"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MonarchBg)
            .padding(horizontal = 20.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(24.dp))

        // Top bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .background(MonarchPurple.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                    .border(1.dp, MonarchPurple.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "TARGET CONFIRMATION",
                    color = MonarchCyan,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            LanguageToggleButton(
                currentLanguage = language,
                onLanguageToggle = onLanguageChange
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Cinematic Monarch Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .clip(RoundedCornerShape(12.dp))
                .border(1.dp, MonarchCyan.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_monarch_hero),
                contentDescription = "Monarch Banner",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Gradient overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, MonarchBg.copy(alpha = 0.9f))
                        )
                    )
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = LanguageManager.getText("target_activation", isArabic),
            color = MonarchTextPrimary,
            fontSize = 24.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 2.sp
        )

        Text(
            text = LanguageManager.getText("target_activation_sub", isArabic),
            color = MonarchCyan,
            fontSize = 13.sp,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Sung Jin-Woo Mentor
        JinWooMentorCard(
            dialogueText = LanguageManager.getText("mentor_arise", isArabic),
            isArabic = isArabic
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Hunter Target Summary Card
        CyberpunkCard(
            modifier = Modifier.fillMaxWidth(),
            borderColor = MonarchBorder
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = MonarchCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = profile.fullName,
                        color = MonarchTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    HunterRankBadge(rank = profile.rank, isArabic = isArabic)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = if (isArabic) "القطاعات المفعلة:" else "Activated Focus Sectors:",
                    color = MonarchTextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(8.dp))

                profile.selectedSectors.forEach { sectorId ->
                    val sec = SectorType.fromId(sectorId)
                    val secName = if (isArabic) sec.nameAr else sec.nameEn
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = sec.color,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = secName,
                            color = MonarchTextPrimary,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Prominent [ ARISE ] Button
        AriseButton(
            text = "[ " + LanguageManager.getText("arise", isArabic) + " ]",
            onClick = {
                onPlayAriseSound()
                onEnterDashboard()
            },
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .testTag("arise_activation_button")
        )

        Spacer(modifier = Modifier.height(36.dp))
    }
}
