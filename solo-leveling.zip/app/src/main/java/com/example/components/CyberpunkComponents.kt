package com.example.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.models.HunterRank
import com.example.ui.theme.MonarchBg
import com.example.ui.theme.MonarchBorder
import com.example.ui.theme.MonarchBorderCyan
import com.example.ui.theme.MonarchCyan
import com.example.ui.theme.MonarchFrameBg
import com.example.ui.theme.MonarchFrameBgLight
import com.example.ui.theme.MonarchPurple
import com.example.ui.theme.MonarchPurpleLight
import com.example.ui.theme.MonarchTextPrimary
import com.example.ui.theme.MonarchTextSecondary

@Composable
fun CyberpunkCard(
    modifier: Modifier = Modifier,
    borderColor: Color = MonarchBorder,
    borderWidth: Dp = 1.dp,
    backgroundColor: Color = MonarchFrameBg,
    content: @Composable () -> Unit
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        border = BorderStroke(borderWidth, borderColor)
    ) {
        content()
    }
}

@Composable
fun AriseButton(
    text: String = "[ ARISE ]",
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    val infiniteTransition = rememberInfiniteTransition(label = "arise_pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_alpha"
    )

    Box(
        modifier = modifier
            .scale(if (enabled) scale else 1f)
            .shadow(
                elevation = 16.dp,
                shape = CutCornerShape(topStart = 12.dp, bottomEnd = 12.dp),
                spotColor = MonarchCyan.copy(alpha = glowAlpha),
                ambientColor = MonarchPurple.copy(alpha = glowAlpha)
            )
            .clip(CutCornerShape(topStart = 12.dp, bottomEnd = 12.dp))
            .background(
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        MonarchPurple,
                        MonarchFrameBg,
                        MonarchCyan
                    )
                )
            )
            .border(
                width = 2.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        MonarchCyan.copy(alpha = glowAlpha),
                        MonarchPurpleLight,
                        MonarchCyan.copy(alpha = glowAlpha)
                    )
                ),
                shape = CutCornerShape(topStart = 12.dp, bottomEnd = 12.dp)
            )
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 3.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun CyberpunkButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isPrimary: Boolean = true,
    enabled: Boolean = true,
    color: Color = if (isPrimary) MonarchCyan else MonarchPurple
) {
    if (isPrimary) {
        Button(
            onClick = onClick,
            enabled = enabled,
            modifier = modifier.height(48.dp),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = color,
                contentColor = MonarchBg,
                disabledContainerColor = MonarchBorder,
                disabledContentColor = MonarchTextSecondary
            )
        ) {
            Text(
                text = text,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                letterSpacing = 1.sp
            )
        }
    } else {
        OutlinedButton(
            onClick = onClick,
            enabled = enabled,
            modifier = modifier.height(48.dp),
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, color),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = color
            )
        ) {
            Text(
                text = text,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                letterSpacing = 1.sp
            )
        }
    }
}

@Composable
fun HunterRankBadge(
    rank: HunterRank,
    isArabic: Boolean = false,
    modifier: Modifier = Modifier
) {
    val title = if (isArabic) rank.titleAr else rank.titleEn
    Box(
        modifier = modifier
            .border(1.5.dp, rank.color, RoundedCornerShape(6.dp))
            .background(rank.color.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            color = rank.color,
            fontSize = 12.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 1.sp
        )
    }
}

@Composable
fun StatBar(
    current: Int,
    max: Int,
    label: String,
    barColor: Color = MonarchCyan,
    modifier: Modifier = Modifier
) {
    val progress = if (max > 0) (current.toFloat() / max.toFloat()).coerceIn(0f, 1f) else 0f

    Column(modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                color = MonarchTextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "$current / $max",
                color = MonarchTextPrimary,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
            color = barColor,
            trackColor = MonarchFrameBgLight,
            strokeCap = StrokeCap.Round
        )
    }
}

@Composable
fun LanguageToggleButton(
    currentLanguage: String,
    onLanguageToggle: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val isArabic = currentLanguage == "ar"
    Box(
        modifier = modifier
            .border(1.dp, MonarchBorderCyan, RoundedCornerShape(20.dp))
            .background(MonarchFrameBgLight, RoundedCornerShape(20.dp))
            .clickable {
                onLanguageToggle(if (isArabic) "en" else "ar")
            }
            .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = if (isArabic) "🌐 العربية" else "🌐 EN",
                color = MonarchCyan,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
