package com.example.data

import android.content.Context
import com.example.models.HunterProfile
import com.example.models.Quest
import com.example.models.QuestType
import com.example.models.SectorType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class UserDataRepository(private val context: Context) {

    private val jsonFile: File
        get() = File(context.filesDir, "user_data.json")

    suspend fun loadData(): Pair<HunterProfile, List<Quest>> = withContext(Dispatchers.IO) {
        if (!jsonFile.exists()) {
            val defaultProfile = HunterProfile(
                fullName = "Sung Jin-Woo",
                email = "hunter@monarch.system",
                age = 24,
                avatarId = "img_jinwoo_mentor",
                level = 1,
                currentXp = 25,
                streakDays = 3,
                totalQuestsCompleted = 4,
                selectedSectors = listOf("STUDY", "BUSINESS", "FITNESS"),
                language = "en",
                soundEnabled = true,
                isLoggedIn = false
            )
            val defaultQuests = getDefaultQuests()
            saveData(defaultProfile, defaultQuests)
            return@withContext Pair(defaultProfile, defaultQuests)
        }

        try {
            val content = jsonFile.readText()
            val root = JSONObject(content)

            val profileObj = root.optJSONObject("profile") ?: JSONObject()
            val sectorsArray = profileObj.optJSONArray("selectedSectors")
            val sectorsList = mutableListOf<String>()
            if (sectorsArray != null) {
                for (i in 0 until sectorsArray.length()) {
                    sectorsList.add(sectorsArray.getString(i))
                }
            } else {
                sectorsList.addAll(listOf("STUDY", "BUSINESS", "FITNESS"))
            }

            val profile = HunterProfile(
                fullName = profileObj.optString("fullName", "Sung Jin-Woo"),
                email = profileObj.optString("email", "hunter@monarch.system"),
                age = profileObj.optInt("age", 24),
                avatarId = profileObj.optString("avatarId", "img_jinwoo_mentor"),
                level = profileObj.optInt("level", 1).coerceAtLeast(1),
                currentXp = profileObj.optInt("currentXp", 0),
                streakDays = profileObj.optInt("streakDays", 1).coerceAtLeast(1),
                totalQuestsCompleted = profileObj.optInt("totalQuestsCompleted", 0),
                selectedSectors = sectorsList,
                language = profileObj.optString("language", "en"),
                soundEnabled = profileObj.optBoolean("soundEnabled", true),
                isLoggedIn = profileObj.optBoolean("isLoggedIn", false)
            )

            val questsArray = root.optJSONArray("quests") ?: JSONArray()
            val quests = mutableListOf<Quest>()
            for (i in 0 until questsArray.length()) {
                val qObj = questsArray.getJSONObject(i)
                val rawQuestType = qObj.optString("questType", if (qObj.optBoolean("isDaily", true)) "DAILY" else "SIDE")
                val isDone = qObj.optBoolean("isCompleted", false)
                val isClaimed = qObj.optBoolean("isClaimed", isDone)
                quests.add(
                    Quest(
                        id = qObj.optString("id", System.currentTimeMillis().toString()),
                        title = qObj.optString("title", "Daily Quest"),
                        titleAr = qObj.optString("titleAr", "مهمة يومية"),
                        description = qObj.optString("description", ""),
                        descriptionAr = qObj.optString("descriptionAr", ""),
                        sector = SectorType.fromId(qObj.optString("sector", "STUDY")),
                        rank = qObj.optString("rank", "E"),
                        durationMinutes = qObj.optInt("durationMinutes", 20),
                        xpReward = qObj.optInt("xpReward", 50),
                        isCompleted = isDone,
                        isClaimed = isClaimed,
                        questType = QuestType.fromId(rawQuestType),
                        isDaily = rawQuestType.equals("DAILY", ignoreCase = true),
                        dueTime = qObj.optString("dueTime", "Today 20:00"),
                        reminderEnabled = qObj.optBoolean("reminderEnabled", false),
                        reminderTimestamp = qObj.optLong("reminderTimestamp", 0L),
                        createdAt = qObj.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }

            Pair(profile, if (quests.isEmpty()) getDefaultQuests() else quests)
        } catch (e: Exception) {
            e.printStackTrace()
            val defaultProfile = HunterProfile()
            val defaultQuests = getDefaultQuests()
            Pair(defaultProfile, defaultQuests)
        }
    }

    suspend fun saveData(profile: HunterProfile, quests: List<Quest>) = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject()

            val profileObj = JSONObject().apply {
                put("fullName", profile.fullName)
                put("email", profile.email)
                put("age", profile.age)
                put("avatarId", profile.avatarId)
                put("level", profile.level)
                put("currentXp", profile.currentXp)
                put("streakDays", profile.streakDays)
                put("totalQuestsCompleted", profile.totalQuestsCompleted)
                put("language", profile.language)
                put("soundEnabled", profile.soundEnabled)
                put("isLoggedIn", profile.isLoggedIn)

                val secArr = JSONArray()
                profile.selectedSectors.forEach { secArr.put(it) }
                put("selectedSectors", secArr)
            }
            root.put("profile", profileObj)

            val questsArr = JSONArray()
            for (q in quests) {
                val qObj = JSONObject().apply {
                    put("id", q.id)
                    put("title", q.title)
                    put("titleAr", q.titleAr)
                    put("description", q.description)
                    put("descriptionAr", q.descriptionAr)
                    put("sector", q.sector.id)
                    put("rank", q.rank)
                    put("durationMinutes", q.durationMinutes)
                    put("xpReward", q.xpReward)
                    put("isCompleted", q.isCompleted)
                    put("isClaimed", q.isClaimed)
                    put("questType", q.questType.id)
                    put("isDaily", q.isDaily)
                    put("dueTime", q.dueTime)
                    put("reminderEnabled", q.reminderEnabled)
                    put("reminderTimestamp", q.reminderTimestamp)
                    put("createdAt", q.createdAt)
                }
                questsArr.put(qObj)
            }
            root.put("quests", questsArr)

            jsonFile.writeText(root.toString(2))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun getDefaultQuests(): List<Quest> {
        return listOf(
            Quest(
                id = "daily_1",
                title = "100 Push-ups, 100 Sit-ups, 100 Squats",
                titleAr = "100 ضغط، 100 بطن، 100 قرفصاء",
                description = "Daily physical training mandated by the Monarch system.",
                descriptionAr = "التدريب البدني اليومي الإلزامي المفروض من قبل النظام الملكي.",
                sector = SectorType.FITNESS,
                rank = "E",
                durationMinutes = 30,
                xpReward = 60,
                isCompleted = false,
                isClaimed = false,
                questType = QuestType.DAILY,
                isDaily = true,
                dueTime = "Today 21:00",
                reminderEnabled = true
            ),
            Quest(
                id = "main_1",
                title = "Deep Focus: Skill Mastery Sprint",
                titleAr = "تركيز عميق: سباق إتقان المهارات",
                description = "Unbroken concentration on technical or academic study.",
                descriptionAr = "تركيز متواصل دون مشتتات على الدراسة التقنية أو الأكاديمية.",
                sector = SectorType.STUDY,
                rank = "D",
                durationMinutes = 45,
                xpReward = 120,
                isCompleted = false,
                isClaimed = false,
                questType = QuestType.MAIN,
                isDaily = false,
                dueTime = "Today 18:00",
                reminderEnabled = true
            ),
            Quest(
                id = "main_2",
                title = "Business Intel & Project Architecture",
                titleAr = "استخبارات الأعمال وهندسة المشاريع",
                description = "Analyze competitive landscape and outline core milestones.",
                descriptionAr = "تحليل المنافسين ووضع المعالم الأساسية لنمو المشروع.",
                sector = SectorType.BUSINESS,
                rank = "C",
                durationMinutes = 40,
                xpReward = 150,
                isCompleted = false,
                isClaimed = false,
                questType = QuestType.MAIN,
                isDaily = false,
                dueTime = "Tomorrow 14:00",
                reminderEnabled = false
            ),
            Quest(
                id = "side_1",
                title = "Sleep & Vital Recovery Protocol",
                titleAr = "بروتوكول النوم واستعادة الحيوية",
                description = "Prepare mind and body with 8 hours of restorative rest.",
                descriptionAr = "تهيئة العقل والجسد بثمان ساعات من الراحة لتجديد المانا.",
                sector = SectorType.FITNESS,
                rank = "E",
                durationMinutes = 15,
                xpReward = 40,
                isCompleted = true,
                isClaimed = true,
                questType = QuestType.SIDE,
                isDaily = false,
                dueTime = "Today 23:30",
                reminderEnabled = false
            )
        )
    }
}
