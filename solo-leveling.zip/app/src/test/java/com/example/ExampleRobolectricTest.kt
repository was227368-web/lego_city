package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Solo Leveling", appName)
  }

  @Test
  fun `xp formula scales with level`() {
    val level1Required = 100 + (1 - 1) * 25
    val level2Required = 100 + (2 - 1) * 25
    val level10Required = 100 + (10 - 1) * 25
    assertEquals(100, level1Required)
    assertEquals(125, level2Required)
    assertEquals(325, level10Required)
  }
}
